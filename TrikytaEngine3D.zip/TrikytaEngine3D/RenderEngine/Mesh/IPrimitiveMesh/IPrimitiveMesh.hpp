#pragma once

#include "Core/Misc/Defines/Common.hpp"
#include "RenderEngine/Scenegraph/Scene/Scene.hpp"

TRE_NS_START

class IPrimitiveMesh
{
public:
    typedef Scene::RenderCommandBuffer RenderCommandBuffer;

    virtual void Submit(RenderCommandBuffer& CmdBucket) = 0; // Shouldd be pure virtual
private:
    
};

TRE_NS_END