#pragma once

#include "Core/Misc/Defines/Common.hpp"
#include "RenderEngine/Mesh/PrimitiveGeometry/PrimitiveGeometry.hpp"
#include "RenderEngine/Materials/Material.hpp"

TRE_NS_START

struct RawSubMesh 
{
    RawSubMesh(PrimitiveGeometry& geo, Material& mat) : 
        m_Geometry(geo), m_Material(std::move(mat))
    {};

    PrimitiveGeometry m_Geometry;
    Material m_Material;
};

TRE_NS_END