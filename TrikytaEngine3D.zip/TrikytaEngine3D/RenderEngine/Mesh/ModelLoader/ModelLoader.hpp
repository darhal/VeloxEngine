#pragma once

#include <Core/Misc/Defines/Common.hpp>
#include <RenderAPI/VertexArray/VAO.hpp>
#include <RenderAPI/VertexBuffer/VBO.hpp>
#include <RenderAPI/General/GLContext.hpp>
#include <RenderAPI/Shader/ShaderProgram.hpp>
#include "ModelSettings.hpp"
#include <Core/Misc/Defines/DataStructure.hpp>
#include <RenderEngine/Materials/Material.hpp>
#include <RenderEngine/Mesh/StaticMesh/StaticMesh.hpp>

TRE_NS_START

struct MatrialForRawModel
{
	const Material& material;
	int32 vcount;
	MatrialForRawModel(const Material& material, int32 vcount) : material(material), vcount(vcount)
	{}

	MatrialForRawModel(const MatrialForRawModel& other) : material(other.material), vcount(other.vcount)
	{}
};

struct VertexData
{
    VertexData(const vec3& p, const vec3& n, const vec2& t) : pos(p), normal(n), texture(t)
    {}
    vec3 pos, normal;
    vec2 texture;
};


class ModelLoader
{
public:
	ModelLoader() = delete; // no default constructor sorry :(

	FORCEINLINE ~ModelLoader();

	template<ssize_t V, ssize_t T, ssize_t N>
	ModelLoader(float(&vert)[V], float(&tex)[T], float(&normal)[N], const Vector<MatrialForRawModel>& mat_vec = {});

	template<ssize_t V, ssize_t I, ssize_t T, ssize_t N>
	ModelLoader(float(&vert)[V], uint32(&indices)[I], float(&tex)[T], float(&normal)[N], const Vector<MatrialForRawModel>& mat_vec = {});

	ModelLoader(const ModelSettings& settings);

	template<ssize_t I>
	ModelLoader(const ModelSettings&, uint32(&indices)[I]);

	ModelLoader(const Vector<vec3>& vertices, const Vector<uint32>& indices, const Vector<vec2>* textures = NULL, const Vector<vec3>* normals = NULL, const Vector<MatrialForRawModel>& mat_vec = {});
	ModelLoader(const Vector<vec3>& vertices, const Vector<vec2>* textures = NULL, const Vector<vec3>* normals = NULL, const Vector<MatrialForRawModel>& mat_vec = {});

	ModelLoader(const Vector<VertexData>& ver_data, const Vector<uint32>& indices, const Vector<MatrialForRawModel>& mat_vec);
	ModelLoader(const Vector<VertexData>& ver_data, const Vector<MatrialForRawModel>& mat_vec);

	void ProcessData(StaticMesh& mesh);

	FORCEINLINE ModelLoader(ModelLoader&& other);

	FORCEINLINE ModelLoader& operator=(ModelLoader&& other);

	FORCEINLINE ModelLoader& operator=(ModelLoader& other) = delete;

	FORCEINLINE ModelLoader(const ModelLoader& other) = delete;


	FORCEINLINE const ssize_t GetVertexCount() const;

	FORCEINLINE const Vector<MatrialForRawModel>& GetMaterials() const;

	FORCEINLINE void Clean();
private:
	// Utility Functions:
	template<ssize_t V, ssize_t T, ssize_t N>
	void LoadFromArray(float(&vert)[V], float(&tex)[T], float(&normal)[N]);
	void LoadFromSettings(const ModelSettings& settings);
	void LoadFromVector(const Vector<vec3>& vertices, const Vector<vec2>* textures, const Vector<vec3>* normals);
	void LoadFromVertexData(const Vector<VertexData>& ver_data);

	VAO m_ModelVAO;
	VBO vertexVBO;
	VBO textureVBO;
	VBO normalVBO;
	VBO indexVBO;
	ssize_t m_VertexCount;
	Vector<MatrialForRawModel> m_Materials;
};

template<ssize_t V, ssize_t T, ssize_t N>
ModelLoader::ModelLoader(float(&vert)[V], float(&tex)[T], float(&normal)[N], const Vector<MatrialForRawModel>& mat_vec)
{
	LoadFromArray(vert, tex, normal);
	m_VertexCount = V / 3LLU; // Get the vertex Count!
	m_ModelVAO.Unuse();
	m_Materials = mat_vec;

	if (m_Materials.IsEmpty()) {
		Material default_material("Unknown");
		m_Materials.EmplaceBack(default_material, m_VertexCount); // default material
	}
}

template<ssize_t V, ssize_t I, ssize_t T, ssize_t N>
ModelLoader::ModelLoader(float(&vert)[V], uint32(&indices)[I], float(&tex)[T], float(&normal)[N], const Vector<MatrialForRawModel>& mat_vec)
{
	LoadFromArray(vert, tex, normal);
	m_VertexCount = I; // Get the vertex Count!
	//Set up indices
	indexVBO.Generate(BufferTarget::ELEMENT_ARRAY_BUFFER);
	indexVBO.FillData(indices);
	m_ModelVAO.Unuse();
	indexVBO.Unuse();
	m_Materials = mat_vec;
	
	if (m_Materials.IsEmpty()) {
		Material default_material("Unknown");
		m_Materials.EmplaceBack(default_material, m_VertexCount); // default material
	}
}

template<ssize_t I>
ModelLoader::ModelLoader(const ModelSettings& settings, uint32(&indices)[I])
{
	ASSERTF((settings.vertexSize == 0 || settings.vertices == NULL), "Attempt to create a ModelLoader with empty vertecies!");
	LoadFromSettings(settings);
	m_VertexCount = I; // Get the vertex Count!
	//Set up indices
	indexVBO.Generate(BufferTarget::ELEMENT_ARRAY_BUFFER);
	indexVBO.FillData(indices);
	m_ModelVAO.Unuse();
	indexVBO.Unuse();
}

FORCEINLINE ModelLoader::ModelLoader(ModelLoader&& other) :
	m_ModelVAO(std::move(other.m_ModelVAO)), vertexVBO(std::move(other.vertexVBO)), textureVBO(std::move(other.textureVBO)),
	normalVBO(std::move(other.normalVBO)), indexVBO(std::move(other.indexVBO)), m_VertexCount(other.m_VertexCount), 
	m_Materials(std::move(other.m_Materials))
{
}

FORCEINLINE ModelLoader& ModelLoader::operator=(ModelLoader&& other) {
	m_ModelVAO = std::move(other.m_ModelVAO);
	vertexVBO = std::move(other.vertexVBO);
	textureVBO = std::move(other.textureVBO);
	normalVBO = std::move(other.normalVBO);
	indexVBO = std::move(other.indexVBO);
	m_VertexCount = std::move(other.m_VertexCount);
	m_Materials = std::move(other.m_Materials);
	return *this;
}

FORCEINLINE const ssize_t ModelLoader::GetVertexCount() const
{
	return m_VertexCount;
}

FORCEINLINE const Vector<MatrialForRawModel>& ModelLoader::GetMaterials() const
{
	return m_Materials;
}

FORCEINLINE ModelLoader::~ModelLoader()
{
	m_ModelVAO.Clean();
	vertexVBO.Clean();
	textureVBO.Clean();
	normalVBO.Clean();
	indexVBO.Clean();
}

FORCEINLINE void ModelLoader::Clean()
{
	m_ModelVAO.Clean();
	vertexVBO.Clean();
	textureVBO.Clean();
	normalVBO.Clean();
	indexVBO.Clean();
}

TRE_NS_END