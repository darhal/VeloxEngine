#include "ModelLoader.hpp"
#include <Core/Context/Extensions.hpp>
#include <RenderAPI/Shader/ShaderProgram.hpp>

TRE_NS_START

ModelLoader::ModelLoader(const Vector<vec3>& vertices, const Vector<uint32>& indices, const Vector<vec2>* textures, const Vector<vec3>* normals, const Vector<MatrialForRawModel>& mat_vec)
{
	ASSERTF((vertices.Size() == 0 || indices.Size() == 0), "Attempt to create a ModelLoader with empty vertecies or empty indices!");
	LoadFromVector(vertices, textures, normals);
	m_VertexCount = indices.Size(); // Get the vertex Count!
	//Set up indices
	indexVBO.Generate(BufferTarget::ELEMENT_ARRAY_BUFFER);
	indexVBO.FillData(&indices.At(0), indices.Size() * sizeof(uint32));
	m_ModelVAO.Unuse();
	indexVBO.Unuse();
	m_Materials = mat_vec;
	if (m_Materials.IsEmpty()) {
		m_Materials.EmplaceBack(Material(), m_VertexCount); // default material
	}
}

ModelLoader::ModelLoader(const Vector<vec3>& vertices, const Vector<vec2>* textures, const Vector<vec3>* normals, const Vector<MatrialForRawModel>& mat_vec)
{
	ASSERTF((vertices.Size() == 0), "Attempt to create a ModelLoader with empty vertecies!");
	
	LoadFromVector(vertices, textures, normals);
	m_VertexCount = vertices.Size() / 3LLU; // Get the vertex Count!
	m_ModelVAO.Unuse();
	m_Materials = mat_vec;
	
	if (m_Materials.IsEmpty()) {
		Material default_material("Unknown");
		m_Materials.EmplaceBack(default_material, m_VertexCount); // default material
	}
}

ModelLoader::ModelLoader(const ModelSettings& settings)
{
	ASSERTF((settings.vertexSize == 0 || settings.vertices == NULL), "Attempt to create a ModelLoader with empty vertecies!");
	LoadFromSettings(settings);
	m_VertexCount = settings.vertexSize / 3LLU; // Get the vertex Count!
	m_ModelVAO.Unuse();
}

ModelLoader::ModelLoader(const Vector<VertexData>& ver_data, const Vector<uint32>& indices, const Vector<MatrialForRawModel>& mat_vec)
{
	ASSERTF((ver_data.Size() == 0 || indices.Size() == 0), "Attempt to create a ModelLoader with empty vertecies!");
	
	LoadFromVertexData(ver_data);

	m_VertexCount = indices.Size(); // Get the vertex Count!
	//Set up indices
	indexVBO.Generate(BufferTarget::ELEMENT_ARRAY_BUFFER);
	indexVBO.FillData(&indices.At(0), indices.Size() * sizeof(uint32));
	m_ModelVAO.Unbind();
	indexVBO.Unbind();

	m_Materials = mat_vec;

	if (m_Materials.IsEmpty()) {
		m_Materials.EmplaceBack(Material(), m_VertexCount); // default material
	}
}

ModelLoader::ModelLoader(const Vector<VertexData>& ver_data, const Vector<MatrialForRawModel>& mat_vec)
{
	ASSERTF((ver_data.Size() == 0), "Attempt to create a ModelLoader with empty vertecies!");
	LoadFromVertexData(ver_data);
	m_VertexCount = ver_data.Size() / 8LLU; // Get the vertex Count!
	m_ModelVAO.Unuse();
	m_Materials = mat_vec;

	if (m_Materials.IsEmpty()) {
		Material default_material("Unknown");
		m_Materials.EmplaceBack(default_material, m_VertexCount); // default material
	}
}

template<ssize_t V, ssize_t T, ssize_t N>
void ModelLoader::LoadFromArray(float(&vert)[V], float(&tex)[T], float(&normal)[N])
{
	m_ModelVAO.Generate();
	m_ModelVAO.Use();

	//Fill vertex:
	vertexVBO.Generate(BufferTarget::ARRAY_BUFFER);
	vertexVBO.FillData(vert);
	m_ModelVAO.BindAttribute<DataType::FLOAT>(0, vertexVBO, 3, 0, 0);

	//Fill normals:
	normalVBO.Generate(BufferTarget::ARRAY_BUFFER);
	normalVBO.FillData(normal);
	m_ModelVAO.BindAttribute<DataType::FLOAT>(1, normalVBO, 3, 0, 0);
	normalVBO.Unuse();

	//Fill Texture:
	textureVBO.Generate(BufferTarget::ARRAY_BUFFER);
	textureVBO.FillData(tex);
	m_ModelVAO.BindAttribute<DataType::FLOAT>(2, textureVBO, 2, 0, 0);
}

void ModelLoader::LoadFromVector(const Vector<vec3>& vertices, const Vector<vec2>* textures, const Vector<vec3>* normals)
{
	ASSERTF((vertices.Size() == 0), "Attempt to create a ModelLoader with empty vertecies!");
	
	m_ModelVAO.Generate();
	m_ModelVAO.Use();

	//Fill vertex:
	vertexVBO.Generate(BufferTarget::ARRAY_BUFFER);
	vertexVBO.FillData(&vertices.At(0), vertices.Size() * sizeof(vec3));
	m_ModelVAO.BindAttribute<DataType::FLOAT>(0, vertexVBO, 3, 0, 0);

	// Fill normals if availble
	if (normals != NULL && normals->Size() != 0) {
		normalVBO.Generate(BufferTarget::ARRAY_BUFFER);
		normalVBO.FillData(&normals->At(0), normals->Size() * sizeof(vec3));
		m_ModelVAO.BindAttribute<DataType::FLOAT>(1, normalVBO, 3, 0, 0);
	}

	//Fill Texture if availble
	if (textures != NULL && textures->Size() != 0) {
		textureVBO.Generate(BufferTarget::ARRAY_BUFFER);
		textureVBO.FillData(&textures->At(0), textures->Size() * sizeof(vec2));
		m_ModelVAO.BindAttribute<DataType::FLOAT>(2, textureVBO, 2, 0, 0);
	}
}

void ModelLoader::LoadFromVertexData(const Vector<VertexData>& ver_data)
{
	ASSERTF((ver_data.Size() == 0), "Attempt to create a ModelLoader with empty vertecies!");

	m_ModelVAO.Generate();
	m_ModelVAO.Bind();

	//Fill vertex:
	vertexVBO.Generate(BufferTarget::ARRAY_BUFFER);
	vertexVBO.FillData(&ver_data.At(0), ver_data.Size() * sizeof(VertexData));
	m_ModelVAO.BindAttribute<float>(0, vertexVBO, DataType::FLOAT, 3, 8, 0);
	m_ModelVAO.BindAttribute<float>(1, vertexVBO, DataType::FLOAT, 3, 8, 3);
	m_ModelVAO.BindAttribute<float>(2, vertexVBO, DataType::FLOAT, 2, 8, 6);
	vertexVBO.Unbind();
}

void ModelLoader::LoadFromSettings(const ModelSettings& settings)
{
	ASSERTF((settings.vertexSize == 0 || settings.vertices == NULL), "Attempt to create a ModelLoader with empty vertecies!");
	
	m_ModelVAO.Generate();
	m_ModelVAO.Use();

	//Fill vertex:
	vertexVBO.Generate(BufferTarget::ARRAY_BUFFER);
	vertexVBO.FillData(settings.vertices, settings.vertexSize * sizeof(float));
	m_ModelVAO.BindAttribute<DataType::FLOAT>(0, vertexVBO, 3, 0, 0);

	if (settings.normalSize != 0 && settings.normals != NULL) { // Fill normals if availble
		//Fill normals:
		normalVBO.Generate(BufferTarget::ARRAY_BUFFER);
		normalVBO.FillData(settings.normals, settings.normalSize * sizeof(float));
		m_ModelVAO.BindAttribute<DataType::FLOAT>(1, normalVBO, 3, 0, 0);
		normalVBO.Unuse();
	}

	if (settings.textureSize != 0 && settings.textures != NULL) { //Fill Texture if availble
		textureVBO.Generate(BufferTarget::ARRAY_BUFFER);
		textureVBO.FillData(settings.textures, settings.textureSize * sizeof(float));
		m_ModelVAO.BindAttribute<DataType::FLOAT>(2, textureVBO, 2, 0, 0);
	}
}

void ModelLoader::ProcessData(StaticMesh& mesh)
{
	VaoID vaoID = GRM::Add<VAO>(std::move(m_ModelVAO));
	mesh.SetVaoID(vaoID);
	int32 lastVertexCount = 0;

	if (indexVBO.GetID()){ // Not = to 0 means that its indexed.
		for (const MatrialForRawModel& mat : m_Materials) {
			PrimitiveGeometry model_geo(DataType::UINT, mat.vcount, lastVertexCount * sizeof(uint32));
			MaterialID matID = GRM::Add<Material>(std::move(const_cast<Material&>(mat.material)));
			mesh.AddSubMesh(model_geo, matID);
			lastVertexCount += mat.vcount;
		}
	}else{
		for (const MatrialForRawModel& mat : m_Materials) {
			PrimitiveGeometry model_geo(lastVertexCount, mat.vcount);
			MaterialID matID = GRM::Add<Material>(std::move(const_cast<Material&>(mat.material)));
			mesh.AddSubMesh(model_geo, matID);
			lastVertexCount += mat.vcount;
		}
	}

	m_ModelVAO.Invalidate();
	vertexVBO.Invalidate();
	textureVBO.Invalidate();
	normalVBO.Invalidate();
	indexVBO.Invalidate();
}

TRE_NS_END