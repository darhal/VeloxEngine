#include "StaticMesh.hpp"
#include "RenderEngine/Managers/ResourcesManager/ResourcesManager.hpp"
#include "RenderEngine/Renderer/Backend/CommandBucket/CommandBucket.hpp"

TRE_NS_START

void StaticMesh::Submit(RenderCommandBuffer& CmdBucket)
{
	for (RawSubMesh& obj : m_Meshs) {  
        Material& material = ResourcesManager::GetGRM().Get<Material>(obj.m_MaterialID);
        typename RenderCommandBuffer::Key key = CmdBucket.GenerateKey(material.m_ShaderID, m_VaoID, obj.m_MaterialID);
		Commands::DrawIndexedCmd* draw_cmd = CmdBucket.template AddCommand<Commands::DrawIndexedCmd>(key);
		draw_cmd->mode = obj.m_Geometry.m_Primitive;
		draw_cmd->type = obj.m_Geometry.m_DataType;
		draw_cmd->count = obj.m_Geometry.m_Count;
		draw_cmd->offset = obj.m_Geometry.m_Offset;
		draw_cmd->model = &m_ModelTransformation;	
		draw_cmd->state_hash = m_StateHash;
	}
}

void StaticMesh::SetRenderState(const StateGroup& state)
{
    m_StateHash = ResourcesManager::GetGRM().AddState(state);
}

TRE_NS_END