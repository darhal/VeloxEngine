#pragma once

#include <Core/DataStructure/Vector/Vector.hpp>
#include <Core/Misc/Maths/Maths.hpp>
#include <RenderAPI/VertexArray/VAO.hpp>
#include <RenderEngine/Mesh/RawSubMesh/RawSubMesh.hpp>
#include <RenderEngine/Renderer/CommandBucket/CommandBucket.hpp>

TRE_NS_START

class ShaderProgram;

class StaticMesh
{
public:
    FORCEINLINE StaticMesh(VAO& vao) : m_VAO(std::move(vao))
    {}

    FORCEINLINE StaticMesh(StaticMesh&& other);

    FORCEINLINE StaticMesh() {}

    FORCEINLINE void AddSubMesh(PrimitiveGeometry& geo, Material& mat);

    FORCEINLINE Mat4f& GetTransformationMatrix();

    FORCEINLINE VAO& GetVAO() const;

    template<typename CmdBuffer>
    void Submit(CmdBuffer& CmdBucket, ShaderProgram* shader);

private:
    FORCEINLINE void SetVAO(VAO& vao);

private:
    Vector<RawSubMesh> m_Meshs;
    VAO m_VAO;
    Mat4f m_ModelTransformation;

    friend class ModelLoader;
};

FORCEINLINE StaticMesh::StaticMesh(StaticMesh&& other) : 
    m_Meshs(std::move(other.m_Meshs)), m_VAO(std::move(other.m_VAO)), m_ModelTransformation(other.m_ModelTransformation)
{}

FORCEINLINE void StaticMesh::AddSubMesh(PrimitiveGeometry& geo, Material& mat)
{
    m_Meshs.EmplaceBack(geo, mat);
}

FORCEINLINE Mat4f& StaticMesh::GetTransformationMatrix()
{
    return m_ModelTransformation;
}

FORCEINLINE void StaticMesh::SetVAO(VAO& vao)
{
    m_VAO = std::move(vao);
}

template<typename CmdBuffer>
void StaticMesh::Submit(CmdBuffer& CmdBucket, ShaderProgram* shader)
{
	for (const RawSubMesh& obj : m_Meshs) {
		Commands::DrawIndexed* draw_cmd = CmdBucket.template AddCommand<Commands::DrawIndexed>(0);
		draw_cmd->mode = obj.m_Geometry.m_Primitive;
		draw_cmd->type = obj.m_Geometry.m_DataType;
		draw_cmd->count = obj.m_Geometry.m_Count;
		draw_cmd->offset = obj.m_Geometry.m_Offset;
		draw_cmd->material = const_cast<Material*>(&obj.m_Material);
		draw_cmd->shader = shader;
		draw_cmd->vao = &m_VAO;
		draw_cmd->model = &m_ModelTransformation;	
	}
}

TRE_NS_END