#pragma once

#include <Core/DataStructure/Vector/Vector.hpp>
#include <Core/Misc/Maths/Maths.hpp>
#include <RenderEngine/Mesh/RawSubMesh/RawSubMesh.hpp>
#include <RenderEngine/Renderer/CommandBucket/CommandBucket.hpp>
#include <RenderEngine/Renderer/Common/Common.hpp>

TRE_NS_START

class ShaderProgram;

class StaticMesh
{
public:
    FORCEINLINE StaticMesh(VaoID vao) : m_VaoID(0)
    {}

    FORCEINLINE StaticMesh(StaticMesh&& other);

    FORCEINLINE StaticMesh() {}

    FORCEINLINE void AddSubMesh(PrimitiveGeometry& geo, MaterialID mat);

    FORCEINLINE Mat4f& GetTransformationMatrix();

    template<typename CmdBuffer>
    void Submit(CmdBuffer& CmdBucket, ShaderID shaderID);

private:
    FORCEINLINE void SetVaoID(VaoID vao);

private:
    Vector<RawSubMesh> m_Meshs;
    VaoID m_VaoID;
    Mat4f m_ModelTransformation;

    friend class ModelLoader;
};

FORCEINLINE StaticMesh::StaticMesh(StaticMesh&& other) : 
    m_Meshs(std::move(other.m_Meshs)), m_VaoID(std::move(other.m_VaoID)), m_ModelTransformation(other.m_ModelTransformation)
{}

FORCEINLINE void StaticMesh::AddSubMesh(PrimitiveGeometry& geo, MaterialID mat)
{
    m_Meshs.EmplaceBack(geo, mat);
}

FORCEINLINE Mat4f& StaticMesh::GetTransformationMatrix()
{
    return m_ModelTransformation;
}

FORCEINLINE void StaticMesh::SetVaoID(VaoID vao)
{
    m_VaoID = vao;
}

template<typename CmdBuffer>
void StaticMesh::Submit(CmdBuffer& CmdBucket, ShaderID shaderID)
{
	for (RawSubMesh& obj : m_Meshs) {
        typename CmdBuffer::Key key = CmdBucket.GenerateKey(shaderID, m_VaoID, obj.m_MaterialID);
		Commands::DrawIndexed* draw_cmd = CmdBucket.template AddCommand<Commands::DrawIndexed>(key);
		draw_cmd->mode = obj.m_Geometry.m_Primitive;
		draw_cmd->type = obj.m_Geometry.m_DataType;
		draw_cmd->count = obj.m_Geometry.m_Count;
		draw_cmd->offset = obj.m_Geometry.m_Offset;
		draw_cmd->materialID = obj.m_MaterialID;
		draw_cmd->shaderID = shaderID;
		draw_cmd->vaoID = m_VaoID;
		draw_cmd->model = &m_ModelTransformation;	
	}
}

TRE_NS_END