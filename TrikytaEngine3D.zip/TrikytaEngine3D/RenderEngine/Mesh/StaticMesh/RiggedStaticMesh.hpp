#pragma once

#include <RenderEngine/Renderer/Common/Common.hpp>
#include "RenderEngine/Mesh/IPrimitiveMesh/IPrimitiveMesh.hpp"
#include <RenderEngine/Mesh/RawSubMesh/RiggedRawSubMesh.hpp>

TRE_NS_START

class ShaderProgram;

class RiggedStaticMesh : public IPrimitiveMesh
{
public:
    FORCEINLINE RiggedStaticMesh(VaoID vao) : m_VaoID(vao), m_StateHash(RenderSettings::DEFAULT_STATE_HASH)
    {}

    FORCEINLINE RiggedStaticMesh() : m_VaoID(0), m_StateHash(RenderSettings::DEFAULT_STATE_HASH) 
    {}

    FORCEINLINE RiggedStaticMesh(RiggedStaticMesh&& other);

    FORCEINLINE void AddSubMesh(PrimitiveGeometry& geo, MaterialID mat, const Mat4f& transform = {});

    FORCEINLINE const RiggedRawSubMesh& GetSubMesh(usize index) const;

    FORCEINLINE RiggedRawSubMesh& GetSubMesh(usize index);

    FORCEINLINE void SetRenderState(StateHash hash);

    void SetRenderState(const class StateGroup& state);

    void Submit(RenderCommandBuffer& CmdBucket) override;

private:
    FORCEINLINE void SetVaoID(VaoID vao);

private:
    Vector<RiggedRawSubMesh> m_Meshs;
    VaoID m_VaoID;
    StateHash m_StateHash;

    friend class ModelLoader;
};

FORCEINLINE RiggedStaticMesh::RiggedStaticMesh(RiggedStaticMesh&& other) : 
    m_Meshs(std::move(other.m_Meshs)), m_VaoID(std::move(other.m_VaoID)), m_StateHash(other.m_StateHash)
{}

FORCEINLINE void RiggedStaticMesh::AddSubMesh(PrimitiveGeometry& geo, MaterialID mat, const Mat4f& transform)
{
    m_Meshs.EmplaceBack(geo, mat, transform);
}

FORCEINLINE const RiggedRawSubMesh& RiggedStaticMesh::GetSubMesh(usize index) const
{
    return m_Meshs.At(index);
}

FORCEINLINE RiggedRawSubMesh& RiggedStaticMesh::GetSubMesh(usize index)
{
    return m_Meshs.At(index);
}

FORCEINLINE void RiggedStaticMesh::SetVaoID(VaoID vao)
{
    m_VaoID = vao;
}

FORCEINLINE void RiggedStaticMesh::SetRenderState(StateHash hash)
{
    m_StateHash = hash;
}

TRE_NS_END