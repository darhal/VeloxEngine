#pragma once

#include <RenderEngine/Mesh/RawSubMesh/RiggedRawSubMesh.hpp>
#include <RenderEngine/Renderer/CommandBucket/CommandBucket.hpp>
#include <RenderEngine/Renderer/Common/Common.hpp>

TRE_NS_START

class ShaderProgram;

class RiggedStaticMesh
{
public:
    FORCEINLINE RiggedStaticMesh(VaoID vao) : m_VaoID(0)
    {}

    FORCEINLINE RiggedStaticMesh(RiggedStaticMesh&& other);

    FORCEINLINE RiggedStaticMesh() {}

    FORCEINLINE void AddSubMesh(PrimitiveGeometry& geo, MaterialID mat, const Mat4f& transform = {});

    FORCEINLINE RiggedRawSubMesh& GetSubMesh(usize index);

    template<typename CmdBuffer>
    void Submit(CmdBuffer& CmdBucket, ShaderID shaderID);

private:
    FORCEINLINE void SetVaoID(VaoID vao);

private:
    Vector<RiggedRawSubMesh> m_Meshs;
    VaoID m_VaoID;

    friend class ModelLoader;
};

FORCEINLINE RiggedStaticMesh::RiggedStaticMesh(RiggedStaticMesh&& other) : 
    m_Meshs(std::move(other.m_Meshs)), m_VaoID(std::move(other.m_VaoID))
{}

FORCEINLINE void RiggedStaticMesh::AddSubMesh(PrimitiveGeometry& geo, MaterialID mat, const Mat4f& transform)
{
    m_Meshs.EmplaceBack(geo, mat, transform);
}

FORCEINLINE RiggedRawSubMesh& RiggedStaticMesh::GetSubMesh(usize index)
{
    return m_Meshs.At(index);
}

FORCEINLINE void RiggedStaticMesh::SetVaoID(VaoID vao)
{
    m_VaoID = vao;
}

template<typename CmdBuffer>
void RiggedStaticMesh::Submit(CmdBuffer& CmdBucket, ShaderID shaderID)
{
	for (RiggedRawSubMesh& obj : m_Meshs) {  
        printf("shaderID : %d, m_VaoID : %d, obj.m_MaterialID : %d \n", shaderID, m_VaoID, obj.m_MaterialID);
        typename CmdBuffer::Key key = CmdBucket.GenerateKey(shaderID, m_VaoID, obj.m_MaterialID);
		Commands::DrawIndexed* draw_cmd = CmdBucket.template AddCommand<Commands::DrawIndexed>(key);
		draw_cmd->mode = obj.m_Geometry.m_Primitive;
		draw_cmd->type = obj.m_Geometry.m_DataType;
		draw_cmd->count = obj.m_Geometry.m_Count;
		draw_cmd->offset = obj.m_Geometry.m_Offset;
		draw_cmd->materialID = obj.m_MaterialID;
        draw_cmd->model = &obj.m_ModelTransformation;
		draw_cmd->shaderID = shaderID;
		draw_cmd->vaoID = m_VaoID;
	}
}

TRE_NS_END