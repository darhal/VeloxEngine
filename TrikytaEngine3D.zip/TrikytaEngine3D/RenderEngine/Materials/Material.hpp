#pragma once

#include <Core/Misc/Defines/Common.hpp>
#include <Core/Misc/Maths/Maths.hpp>
#include <Core/Misc/Utils/Common.hpp>
#include <Core/DataStructure/HashMap/HashMap.hpp>
#include <Core/DataStructure/String/String.hpp>
#include <RenderEngine/Renderer/Common/Common.hpp>
#include <RenderEngine/Materials/Techniques/Technique.hpp>

TRE_NS_START

class Material
{
public:
	FORCEINLINE Material();

	FORCEINLINE explicit Material(const String& m_Name);

	FORCEINLINE Material(Material&& other);

	void AddTexture(const ShaderProgram::Uniform& uniform, const char* tex_path);

	void GenerateShader();

	FORCEINLINE Technique& GetTechnique();

	NULL_COPY_AND_ASSIGN(Material);

public:
	Technique m_Technique;
	String m_Name;

	friend class MaterialLoader;
	friend class IPrimitiveMesh;
};

FORCEINLINE Material::Material(const String& name) :m_Technique(), m_Name(name)
{
}

FORCEINLINE Material::Material() : m_Technique(), m_Name("Default")
{
}

FORCEINLINE Technique& Material::GetTechnique()
{
	return m_Technique;
}

FORCEINLINE Material::Material(Material&& other) : 
	m_Technique(std::move(other.m_Technique)), m_Name(std::move(other.m_Name))
{
}

TRE_NS_END