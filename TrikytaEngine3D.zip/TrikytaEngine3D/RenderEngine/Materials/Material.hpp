#pragma once

#include <Core/Misc/Defines/Common.hpp>
#include <Core/Misc/Maths/Maths.hpp>
#include <Core/Misc/Utils/Common.hpp>
#include <Core/DataStructure/HashMap/Map.hpp>
#include <Core/DataStructure/String/String.hpp>
#include <RenderEngine/Renderer/Common/Common.hpp>

TRE_NS_START

class Material
{
public:
	enum TextureMap {
		DIFFUSE  = 0,
		SPECULAR = 1,
		AMBIENT  = 2,
	};

	FORCEINLINE Material();

	FORCEINLINE explicit Material(const String& m_Name);

	FORCEINLINE Material(const vec3& ambient, const vec3& diffuse, const vec3& specular);

	FORCEINLINE Material(Material&& other);

	FORCEINLINE Material(const Material& other) = delete;

	void AddTexture(const TextureMap& type, const char* tex_path);

	void GenerateShader();

	bool IsBlending() const { return m_Blending; }
	
public:
	String m_Name;

	vec3 m_Ambient;
	vec3 m_Diffuse;
	vec3 m_Specular;
	float m_Shininess;
	float m_Alpha = 1.0f;

	Map<TextureMap, TextureID> m_Textures;

	ShaderID m_ShaderID;
	bool m_Blending;

	friend class MaterialLoader;
	friend class IPrimitiveMesh;
};


FORCEINLINE Material::Material(const vec3& ambient, const vec3& diffuse, const vec3& specular) :
	m_Ambient(ambient), m_Diffuse(diffuse), m_Specular(specular), 
	m_Textures(), m_ShaderID(0), m_Blending(false)
{
}

FORCEINLINE Material::Material(const String& name) : m_Name(name), m_ShaderID(0), m_Blending(false)
{
}

FORCEINLINE Material::Material() :
	m_Name("Default"), m_Ambient(vec3{ 1.f, 1.f, 1.f }),
	m_Diffuse(vec3(0.64f, 0.64f, 0.64f)), m_Specular(vec3(1.f, 1.f, 1.f)), 
	m_Textures(), m_ShaderID(0), m_Blending(false)
{
}

FORCEINLINE Material::Material(Material&& other) : 
	m_Name(std::move(other.m_Name)), m_Ambient(other.m_Ambient), m_Diffuse(other.m_Diffuse), m_Specular(other.m_Specular),
	m_Shininess(other.m_Shininess), m_Textures(std::move(other.m_Textures)), m_ShaderID(other.m_ShaderID), 
	m_Blending(other.m_Blending)
{
}

TRE_NS_END