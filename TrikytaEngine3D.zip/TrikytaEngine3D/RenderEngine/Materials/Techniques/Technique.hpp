#pragma once

#include <Core/Misc/Defines/Common.hpp>
#include <Core/DataStructure/HashMap/HashMap.hpp>
#include <Core/Misc/Maths/Maths.hpp>

#include <RenderAPI/Shader/ShaderProgram.hpp>
#include <RenderEngine/Renderer/Common/Common.hpp>

TRE_NS_START

class Technique
{
public:
    FORCEINLINE Technique(ShaderID shaderID = 0);

    FORCEINLINE Technique(Technique&& other);

    FORCEINLINE void SetUniformMat4(const ShaderProgram::Uniform& uniform, const mat4& mat);

    FORCEINLINE void SetUniformVec3(const ShaderProgram::Uniform& uniform, const vec3& vec);

    FORCEINLINE void SetUniformFloat(const ShaderProgram::Uniform& uniform, float real);

    FORCEINLINE void SetUnfirmSampler(const ShaderProgram::Uniform& uniform, TextureID sampler);

    void UploadUnfiroms(const ShaderProgram& program) const;

    FORCEINLINE void SetShaderID(ShaderID shader_id);

    FORCEINLINE ShaderID GetShaderID() const;

private:
    HashMap<uint8, mat4, PROBING> m_Mat4fs;
    HashMap<uint8, vec3, PROBING> m_Vec3s;
    HashMap<uint8, float, PROBING> m_Floats;
    HashMap<uint8, TextureID, PROBING> m_Textures;

    ShaderID m_ShaderID;
};

FORCEINLINE Technique::Technique(ShaderID shaderID) :
    m_Mat4fs(), m_Vec3s(), m_Floats(), m_Textures(), 
    m_ShaderID(shaderID)
{
}

FORCEINLINE void Technique::SetUniformMat4(const ShaderProgram::Uniform& uniform, const mat4& mat)
{
    m_Mat4fs.Emplace(uniform.value, mat);
}

FORCEINLINE void Technique::SetUniformVec3(const ShaderProgram::Uniform& uniform, const vec3& vec)
{
    m_Vec3s.Emplace(uniform.value, vec);
}

FORCEINLINE void Technique::SetUniformFloat(const ShaderProgram::Uniform& uniform, float real)
{
    m_Floats.Emplace(uniform.value, real);
}

FORCEINLINE void Technique::SetUnfirmSampler(const ShaderProgram::Uniform& uniform, TextureID sampler)
{
    m_Textures.Emplace(uniform.value, sampler);
}

FORCEINLINE void Technique::SetShaderID(ShaderID shader_id)
{
    m_ShaderID = shader_id;
    m_Mat4fs.Clear();
    m_Vec3s.Clear();
    m_Floats.Clear();
    m_Textures.Clear();
}

FORCEINLINE ShaderID Technique::GetShaderID() const
{
    return m_ShaderID;
}

FORCEINLINE Technique::Technique(Technique&& other) : 
    m_Mat4fs(std::move(other.m_Mat4fs)),
    m_Vec3s(std::move(other.m_Vec3s)),
    m_Floats(std::move(other.m_Floats)),
    m_Textures(std::move(other.m_Textures)),
    m_ShaderID(other.m_ShaderID)
{
}

TRE_NS_END