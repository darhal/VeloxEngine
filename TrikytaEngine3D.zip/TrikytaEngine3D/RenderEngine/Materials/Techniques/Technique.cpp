#include "Technique.hpp"
#include "RenderEngine/Managers/ResourcesManager/ResourcesManager.hpp"

TRE_NS_START

void Technique::UploadUnfiroms(const ShaderProgram& program) const
{
    for(const auto& uniform_data : m_MaterialParams.m_Mat4fs){
        program.SetMat4(uniform_data.first, uniform_data.second);
    }

    for(const auto& uniform_data : m_MaterialParams.m_Vec3s){
        program.SetVec3(uniform_data.first, uniform_data.second);
    }

    for(const auto& uniform_data : m_MaterialParams.m_Floats){
        program.SetFloat(uniform_data.first, uniform_data.second);
    }

    // m_Textures; // TODO : its little bit different
}

void Technique::SetupAllUniforms(const AbstractMaterial& abstract_material)
{
    // Query shader by ID from the reource manager :
    ShaderProgram& shader = ResourcesManager::GetGRM().Get<ShaderProgram>(m_ShaderID);

    // for each built in type supported by GLSL set the uniforms one by one :
    this->SetupAllUniformsFromSameType<mat4>(shader, abstract_material);
	this->SetupAllUniformsFromSameType<vec3>(shader, abstract_material);
	this->SetupAllUniformsFromSameType<float>(shader, abstract_material);
	this->SetupAllUniformsFromSameType<TextureID>(shader, abstract_material);
}

TRE_NS_END