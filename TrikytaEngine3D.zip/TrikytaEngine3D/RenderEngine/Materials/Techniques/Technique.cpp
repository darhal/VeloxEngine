#include "Technique.hpp"

TRE_NS_START

void Technique::UploadUnfiroms(const ShaderProgram& program) const
{

    for(const auto& uniform_data : m_Mat4fs){
        program.SetMat4(uniform_data.first, uniform_data.second);
    }

    for(const auto& uniform_data : m_Vec3s){
        program.SetVec3(uniform_data.first, uniform_data.second);
    }

    for(const auto& uniform_data : m_Floats){
        program.SetFloat(uniform_data.first, uniform_data.second);
    }

    // m_Textures; // TODO : its little bit different
}

TRE_NS_END