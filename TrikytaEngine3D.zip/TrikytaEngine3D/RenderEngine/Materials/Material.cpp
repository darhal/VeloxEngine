#include "Material.hpp"
#include "RenderEngine/Managers/ResourcesManager/ResourcesManager.hpp"
#include <RenderAPI/Texture/Texture.hpp>

TRE_NS_START

void Material::AddTexture(const TextureMap& type, const char* tex_path)
{
	printf("Loading the texture : %s\n", tex_path);
	TextureID texID;
	ResourcesManager::GetGRM().Create<Texture>(texID, tex_path, TexTarget::TEX2D, 
		std::initializer_list<TexParamConfig>{
			{TexParam::TEX_WRAP_S , TexWrapping::REPEAT},
			{TexParam::TEX_WRAP_T, TexWrapping::REPEAT},
			{TexParam::TEX_MIN_FILTER, TexFilter::LINEAR},
			{TexParam::TEX_MAG_FILTER, TexFilter::LINEAR}
		}
	);
	m_Textures.Emplace(type, texID);
}

void Material::GenerateShader()
{
	m_ShaderID = 0;
}

TRE_NS_END