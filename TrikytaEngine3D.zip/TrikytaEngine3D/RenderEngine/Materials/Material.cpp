#include "Material.hpp"
#include <RenderAPI/Texture/Texture.hpp>
#include "RenderEngine/Managers/ResourcesManager/ResourcesManager.hpp"
#include "RenderEngine/Materials/AbstractMaterial/AbstractMaterial.hpp"
#include "RenderEngine/Materials/MaterialParametres/MaterialParamHelper.hpp"

TRE_NS_START

Material::Material(const AbstractMaterial& abstract_material) : m_Name(abstract_material.GetName())
{
	this->Init(abstract_material);
}

void Material::AddTexture(const ShaderProgram::Uniform& uniform, const char* tex_path)
{
	printf("Loading the texture : %s\n", tex_path);
	TextureID texID;
	ResourcesManager::GetGRM().Create<Texture>(texID, tex_path, TexTarget::TEX2D, 
		std::initializer_list<TexParamConfig>{
			{TexParam::TEX_WRAP_S , TexWrapping::REPEAT},
			{TexParam::TEX_WRAP_T, TexWrapping::REPEAT},
			{TexParam::TEX_MIN_FILTER, TexFilter::LINEAR},
			{TexParam::TEX_MAG_FILTER, TexFilter::LINEAR}
		}
	);
	
	m_Technique.SetUniform<TextureID>(uniform, texID);
}

void Material::GenerateShader()
{
}

void Material::Setup(const AbstractMaterial& abstract_material)
{
	// Setup the name :
	this->m_Name = abstract_material.GetName();

	// Intilize other variables :
	this->Init(abstract_material);
}

void Material::Init(const AbstractMaterial& abstract_material)
{
	// Setup the technique :
	Technique& techniue = this->GetTechnique();
	techniue.SetupAllUniforms(abstract_material);

	// TODO : Maybe in the future setup rendering states... (Blending etc..)
}

TRE_NS_END