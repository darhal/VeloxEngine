#pragma once

#include "Core/Misc/Defines/Common.hpp"
#include <Core/DataStructure/String/String.hpp>
#include <RenderEngine/Materials/MaterialParametres/MaterialParametres.hpp>

TRE_NS_START

class AbstractMaterial
{
public:
    typedef MaterialParametres<String> MaterialParametresContainer;

public:
    AbstractMaterial();

    AbstractMaterial(const String& name);

    TextureID AddTexture(const String& path);

    FORCEINLINE const MaterialParametresContainer& GetParametres() const;

    FORCEINLINE MaterialParametresContainer& GetParametres();

    FORCEINLINE const String& GetName() const;
private:
    MaterialParametresContainer m_MaterialParams;

    String m_Name;
};

FORCEINLINE AbstractMaterial::AbstractMaterial() : 
    m_MaterialParams(),
    m_Name("DEFAULT")
{
}

FORCEINLINE AbstractMaterial::AbstractMaterial(const String& name) :
    m_MaterialParams(),
    m_Name(name)
{
}

FORCEINLINE const typename AbstractMaterial::MaterialParametresContainer& AbstractMaterial::GetParametres() const
{
    return m_MaterialParams;
}

FORCEINLINE typename AbstractMaterial::MaterialParametresContainer& AbstractMaterial::GetParametres()
{
    return m_MaterialParams;
}

FORCEINLINE const String& AbstractMaterial::GetName() const
{
    return m_Name;
}

TRE_NS_END