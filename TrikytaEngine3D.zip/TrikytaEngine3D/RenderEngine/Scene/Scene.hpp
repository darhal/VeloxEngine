#pragma once

#include "Core/Misc/Defines/Common.hpp"

TRE_NS_START

class Scene
{
public:
    Scene() {};
private:
};

TRE_NS_END