#pragma once

#include "Core/Misc/Defines/Common.hpp"
#include "RenderEngine/RenderResourcesManager/RenderResourcesManager.hpp"

TRE_NS_START

class Scene
{
public:
    Scene() {};

    FORCEINLINE RenderResourcesManager& GetResourcesManager();

private:
    RenderResourcesManager m_RRM;
};

FORCEINLINE RenderResourcesManager& Scene::GetResourcesManager()
{
    return m_RRM;
}

TRE_NS_END