#pragma once

#include "Core/Misc/Defines/Common.hpp"
#include "RenderAPI/General/GLContext.hpp"
#include "RenderEngine/Renderer/Dispatcher/DrawCallsDispatcher.hpp"

TRE_NS_START

typedef void (*BackendDispatchFunction)(const void*);

struct Commands
{
    struct BasicCommand
    {
        // CONSTEXPR static BackendDispatchFunction DISPATCH_FUNCTION;
    };

    struct Draw : public BasicCommand
    {
        // some data ...
        Primitive::primitive_t mode;
        int32 start; 
        int32 end;
        
        CONSTEXPR static BackendDispatchFunction DISPATCH_FUNCTION = &BackendDispatch::Draw;
    };
};

TRE_NS_END