#pragma once

#include "Core/Misc/Defines/Common.hpp"
#include "RenderAPI/General/GLContext.hpp"
#include "RenderEngine/Renderer/Dispatcher/DrawCallsDispatcher.hpp"
#include "RenderEngine/Renderer/Common/Common.hpp"

TRE_NS_START

typedef void (*BackendDispatchFunction)(const void*);

class ShaderProgram;
class VAO;
class Material;

struct Commands
{
    struct BasicCommand
    {
        // CONSTEXPR static BackendDispatchFunction DISPATCH_FUNCTION;
        Mat4f* model;
    };

    struct Draw : public BasicCommand
    {
        // some data ...
        Primitive::primitive_t mode;
        int32 start; 
        int32 end;

        CONSTEXPR static BackendDispatchFunction DISPATCH_FUNCTION = &BackendDispatch::Draw;
    };

    struct DrawIndexed : public BasicCommand
    {
        // some data ...
        Primitive::primitive_t mode;
        DataType::data_type_t type; 
        int32 count; 
        intptr offset;

        CONSTEXPR static BackendDispatchFunction DISPATCH_FUNCTION = &BackendDispatch::DrawIndexed;
    };
};

TRE_NS_END