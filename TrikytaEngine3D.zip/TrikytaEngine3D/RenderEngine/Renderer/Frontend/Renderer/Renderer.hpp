#pragma once

#include "Core/Misc/Defines/Common.hpp"
#include "RenderEngine/Renderer/Frontend/IRenderer/IRenderer.hpp"

TRE_NS_START

class Renderer : public IRenderer
{
public:
    Renderer() = default;

    void Render(const Scene& scene) override;

private:
};

TRE_NS_END