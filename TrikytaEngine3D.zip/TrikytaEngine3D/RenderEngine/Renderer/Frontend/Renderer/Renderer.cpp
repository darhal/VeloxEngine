#include "Renderer.hpp"

TRE_NS_START

void Renderer::Render(const Scene& scene)
{
    m_ResourcesCommandBuffer.Submit();
    m_RenderCommandBuffer.Submit(scene);
}

TRE_NS_END