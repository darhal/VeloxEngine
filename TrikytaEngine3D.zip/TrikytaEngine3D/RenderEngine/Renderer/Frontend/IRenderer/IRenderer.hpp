#include "Core/Misc/Defines/Common.hpp"

TRE_NS_START

class IPrimitiveMesh;

class IRenderer
{
public:
    virtual void AddModelInstance(IPrimitiveMesh* primitive_mesh);

    virtual void Render() = 0;
private:

};

TRE_NS_END