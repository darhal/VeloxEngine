#pragma once

#include "Core/Misc/Defines/Common.hpp"
#include <Core/DataStructure/Vector/Vector.hpp>
#include "RenderEngine/Renderer/CommandPacket/CommandPacket.hpp"
#include "RenderEngine/Renderer/Camera/Camera.hpp"
#include "Core/Misc/Maths/Maths.hpp"
#include "RenderAPI/Shader/ShaderProgram.hpp"
#include "RenderEngine/Scene/Scene.hpp"
#include <algorithm>
#include <Core/DataStructure/Tuple/Pair.hpp>

TRE_NS_START

template<typename T>
class CommandBucket
{
public:
    typedef T Key;

    CommandBucket(Scene& scene, const Camera& cam, const mat4& proj) :  m_Current(0), m_Scene(scene), m_Camera(cam), m_Projection(proj)
    {}

    template<typename U>
    U* AddCommand(Key key, usize aux_memory = 0);

    Key GenerateKey(shader_id_encoding_ext shaderID, uint32 vaoID, uint32 matID) const;

    void DecodeKey(Key key, ShaderID& shaderID, VaoID& vaoID, MaterialID& matID) const;

    void Submit() const;

    void Sort();

private:
    void SubmitPacket(const CmdPacket packet) const;

private:
    Vector<Pair<Key, uint32>> m_Keys;
    Vector<void*> m_Packets;
    //void** m_Packets;
    usize m_Current;

    Scene& m_Scene;
    const Camera& m_Camera;
    const mat4& m_Projection;
   
};

template<typename T>
typename CommandBucket<T>::Key CommandBucket<T>::GenerateKey(shader_id_encoding_ext shaderID, uint32 vaoID, uint32 matID) const
{
    Key key = 0;

    shader_id_encoding sid = m_Scene.GetResourcesManager().GetShaderArray().CompressID(shaderID);
    uint16 vao_id  = m_Scene.GetResourcesManager().GetVaoArray().CompressID(vaoID);
    uint16 mat_id = m_Scene.GetResourcesManager().GetMaterialArray().CompressID(matID);

#if ENDIANNESS == LITTLE_ENDIAN
    key = (Key(sid) << (sizeof(uint16) + sizeof(uint16)) * BITS_PER_BYTE) | (Key(vao_id) << (sizeof(uint16) * BITS_PER_BYTE)) | Key(mat_id);
#else
    key = (Key(vao_id) << (sizeof(uint16) + sizeof(shader_id_encoding)) * BITS_PER_BYTE) | (Key(mat_id) << (sizeof(shader_id_encoding) * BITS_PER_BYTE)) | Key(sid);
#endif

    // printf("\033[1;31m* Encode : ShaderID = %d | vaoID = %d| matID = %d |-->Key = %lu\n", sid, vao_id, mat_id, key);
    return key;
}

template<typename T>
void CommandBucket<T>::DecodeKey(Key key, ShaderID& shaderID, VaoID& vaoID, MaterialID& matID) const
{
#if ENDIANNESS == LITTLE_ENDIAN
    shaderID = ShaderID(shader_id_encoding(key >> (sizeof(uint16) + sizeof(uint16)) * BITS_PER_BYTE));
    vaoID = VaoID(m_Scene.GetResourcesManager().GetVaoArray().CompressID(uint16(key >> (sizeof(uint16) * BITS_PER_BYTE))));
    matID = MaterialID(m_Scene.GetResourcesManager().GetMaterialArray().CompressID(uint16(key)));
#else
    key = (Key(vao_id) << (sizeof(uint16) + sizeof(shader_id_encoding)) * BITS_PER_BYTE) | (Key(mat_id) << (sizeof(shader_id_encoding) * BITS_PER_BYTE)) | Key(sid);
#endif

    // printf("\033[1;32m* Decode : ShaderID = %d | vaoID = %d| matID = %d |-->Key = %lu\n", shaderID, vaoID, matID, key);
}

template<typename T>
void CommandBucket<T>::Sort()
{
    std::qsort(m_Keys.Front(), m_Keys.Length(), sizeof(Pair<Key, uint32>), [](const void* a, const void* b){
        const Pair<Key, uint32>& arg1 = *static_cast<const Pair<Key, uint32>*>(a);
        const Pair<Key, uint32>& arg2 = *static_cast<const Pair<Key, uint32>*>(b);
 
        if(arg1.first < arg2.first) return -1;
        if(arg1.first > arg2.first) return 1;
        return 0;

    });

    for(Pair<Key, uint32>& k : m_Keys){
        printf("Key = %lu\n", k.first);
    }
}

template<typename T>
template<typename U>
U* CommandBucket<T>::AddCommand(T key , usize aux_memory)
{
    CmdPacket packet = CommandPacket::template Create<U>(aux_memory);
 
    // store key and pointer to the data
    {
        // TODO: add some kind of lock or atomic operation here
        // const unsigned int current = m_Current++;
        m_Keys.EmplaceBack(key, m_Packets.Length()); // Tmporary alternative to : m_Keys[current] = key;
        m_Packets.EmplaceBack(packet); // Tmporary alternative to : m_Packets[current] = packet;
    }
 
    CommandPacket::StoreNextCommandPacket(packet, NULL);
    CommandPacket::StoreBackendDispatchFunction(packet, U::DISPATCH_FUNCTION);
 
    return CommandPacket::template GetCommand<U>(packet);
}

template<typename T>
void CommandBucket<T>::Submit() const
{
    // SetViewMatrix();
    // SetProjectionMatrix();
    // SetRenderTargets();

    mat4 pv = m_Projection * m_Camera.GetViewMatrix();
    // m_Current = m_Packets.Length();

    Key lastKey = -1;
    MaterialID lastMatID = -1;
    VaoID lastVaoID = -1;
    ShaderID lastShaderID = -1;
    ShaderProgram* lastShader = NULL;

    for(Pair<Key, uint32>& k : m_Keys){
        Key key = k.first;
        CmdPacket packet = m_Packets[k.second];
       

        if (k.first != lastKey){
            Commands::BasicCommand* command = reinterpret_cast<Commands::BasicCommand*>(const_cast<void*>(CommandPacket::LoadCommand(packet)));
            MaterialID matID;
            VaoID vaoID;
            ShaderID shaderID;
            this->DecodeKey(key, shaderID, vaoID, matID);

            if (shaderID != lastShaderID){
                lastShader = &m_Scene.GetResourcesManager().GetShader(shaderID);
                lastShader->Bind();
                lastShaderID = shaderID;
            }

            if (vaoID != lastVaoID){
                VAO& vao = m_Scene.GetResourcesManager().GetVAO(command->vaoID);
                vao.Bind();
                lastVaoID = vaoID;
            }

            if(matID != lastMatID){
                Material& material = m_Scene.GetResourcesManager().GetMaterial(matID);

                if (!lastShader){
                    lastShader = &m_Scene.GetResourcesManager().GetShader(shaderID);
                }

                for (const auto& tex : material.m_Textures) {
                    glActiveTexture(GL_TEXTURE0 + tex.first);
                    tex.second.Use();
                }

                lastShader->SetMat4("MVP", pv * *(command->model));
		        lastShader->SetMat4("model", *command->model);
                lastShader->SetVec3("material.diffuse", material.m_Diffuse);
		        lastShader->SetVec3("material.ambient", material.m_Ambient);
		        lastShader->SetVec3("material.specular", material.m_Specular);
		        lastShader->SetFloat("material.shininess", material.m_Shininess);
                lastMatID = matID;
            }
        }

        do{
            this->SubmitPacket(packet);
            packet = CommandPacket::LoadNextCommandPacket(packet);
        } while (packet != NULL);
    }

    /* for (usize i = 0; i <  m_Packets.Length(); ++i){
        // Key key = m_Keys[i];
        CmdPacket packet = m_Packets[i];

        // Decode the key, and set shaders, textures, constants, etc. if the material has changed.
        // DecodeKey();

        Commands::BasicCommand* command = reinterpret_cast<Commands::BasicCommand*>(const_cast<void*>(CommandPacket::LoadCommand(packet)));
        
        Material& material = m_Scene.GetResourcesManager().GetMaterial(command->materialID);
        ShaderProgram& shader = m_Scene.GetResourcesManager().GetShader(command->shaderID);
        VAO& vao = m_Scene.GetResourcesManager().GetVAO(command->vaoID);

        shader.Use();
        shader.SetMat4("MVP", pv * *(command->model));
		shader.SetMat4("model", *command->model);
        shader.SetVec3("material.diffuse", material.m_Diffuse);
		shader.SetVec3("material.ambient", material.m_Ambient);
		shader.SetVec3("material.specular", material.m_Specular);
		shader.SetFloat("material.shininess", material.m_Shininess);
        vao.Use();
        
        do{
            this->SubmitPacket(packet);
            packet = CommandPacket::LoadNextCommandPacket(packet);
        } while (packet != NULL);
    }*/
}

template<typename T>
void CommandBucket<T>::SubmitPacket(const CmdPacket packet) const
{
    const BackendDispatchFunction CommandFunction = CommandPacket::LoadBackendDispatchFunction(packet);
    const void* command = CommandPacket::LoadCommand(packet);
    CommandFunction(command);
}

  
TRE_NS_END