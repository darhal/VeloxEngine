#pragma once

#include "Core/Misc/Defines/Common.hpp"
#include <Core/DataStructure/Vector/Vector.hpp>
#include "RenderEngine/Renderer/CommandPacket/CommandPacket.hpp"


TRE_NS_START

template<typename T>
class CommandBucket
{
public:
    typedef T Key;

    CommandBucket() :  m_Packets(NULL), m_Current(0) 
    {}

    template<typename U>
    U* AddCommand(Key key, usize aux_memory = 0);

    void Submit() const;

private:
    void SubmitPacket(const CmdPacket packet) const;

private:
    Vector<Key> m_Keys;
    void** m_Packets;
    usize m_Current;
};

template<typename T>
template<typename U>
U* CommandBucket<T>::AddCommand(T key , usize aux_memory)
{
    CmdPacket packet = CommandPacket::template Create<U>(aux_memory);
 
    // store key and pointer to the data
    {
        // TODO: add some kind of lock or atomic operation here
        const unsigned int current = m_Current++;
        m_Keys.EmplaceBack(key); // Tmporary alternative to m_Keys[current] = key;
        m_Packets[current] = packet;
    }
 
    CommandPacket::StoreNextCommandPacket(packet, NULL);
    CommandPacket::StoreBackendDispatchFunction(packet, U::DISPATCH_FUNCTION);
 
    return CommandPacket::template GetCommand<U>(packet);
}

template<typename T>
void CommandBucket<T>::Submit() const
{
    // SetViewMatrix();
    // SetProjectionMatrix();
    // SetRenderTargets();
 
    for (usize i = 0; i < m_Current; ++i){
        // Key key = m_Keys[i];
        CmdPacket packet = m_Packets[i];

        // Decode the key, and set shaders, textures, constants, etc. if the material has changed.
        // DecodeKey();

        do{
            this->SubmitPacket(packet);
            packet = CommandPacket::LoadNextCommandPacket(packet);
        } while (packet != NULL);
    }
}

template<typename T>
void CommandBucket<T>::SubmitPacket(const CmdPacket packet) const
{
    const BackendDispatchFunction CommandFunction = CommandPacket::LoadBackendDispatchFunction(packet);
    const void* command = CommandPacket::LoadCommand(packet);
    CommandFunction(command);
}
  
TRE_NS_END