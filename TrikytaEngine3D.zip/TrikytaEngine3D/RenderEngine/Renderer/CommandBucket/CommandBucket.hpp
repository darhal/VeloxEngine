#pragma once

#include <algorithm>

#include "Core/Misc/Maths/Maths.hpp"
#include "Core/Misc/Defines/Common.hpp"
#include "Core/DataStructure/Tuple/Pair.hpp"
#include "Core/DataStructure/Vector/Vector.hpp"

#include "RenderEngine/Scenegraph/Scene/Scene.hpp"
#include "RenderEngine/Renderer/Camera/Camera.hpp"
#include "RenderEngine/Renderer/CommandPacket/CommandPacket.hpp"
#include "RenderEngine/Managers/ResourcesManager/ResourcesManager.hpp"

TRE_NS_START

template<typename T>
class CommandBucket
{
public:
    typedef T Key;

    CommandBucket() :  m_Current(0)
    {}

    template<typename U>
    U* AddCommand(Key key, usize aux_memory = 0);

    Key GenerateKey(typename RMI<ShaderProgram>::ID shaderID, typename RMI<VAO>::ID vaoID, typename RMI<Material>::ID matID) const;

    void DecodeKey(Key key, typename RMI<ShaderProgram>::ID& shaderID, typename RMI<VAO>::ID& vaoID, typename RMI<Material>::ID& matID) const;

    void Submit(Scene& scene) const;

    void Sort();

private:
    void SubmitPacket(const CmdPacket packet) const;

private:
    Vector<Pair<Key, uint32>> m_Keys;
    Vector<void*> m_Packets; //void** m_Packets;
    usize m_Current;   
};

template<typename T>
using CommandBuffer = CommandBucket<T>;

#include "CommandBucket.inl"

TRE_NS_END