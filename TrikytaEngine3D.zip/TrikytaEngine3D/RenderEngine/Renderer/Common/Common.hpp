#include "Core/Misc/Defines/Common.hpp"
#include <Core/DataStructure/PackedArray/PackedArray.hpp>
#include <RenderAPI/VertexArray/VAO.hpp>
#include <RenderAPI/VertexBuffer/VBO.hpp>
#include <RenderAPI/FrameBuffer/FBO.hpp>
#include <RenderAPI/RenderBuffer/RBO.hpp>
#include <RenderAPI/Texture/Texture.hpp>
#include <RenderAPI/Shader/ShaderProgram.hpp>
#include <RenderEngine/Materials/Material.hpp>

TRE_NS_START

typedef PackedArray<Texture> TexturePackedArray;

typedef PackedArray<VAO> VaoPackedArray;

typedef PackedArray<VBO> VboPackedArray;

typedef PackedArray<RBO> RboPackedArray;

typedef PackedArray<FBO> FboPackedArray;

typedef uint8 shader_id_encoding;
typedef uint16 shader_id_encoding_ext;
typedef PackedArray<ShaderProgram, 256, shader_id_encoding_ext, shader_id_encoding> ShaderPackedArray;

typedef PackedArray<Material> MaterialPackedArray;


typedef TexturePackedArray::ID TextureID;
typedef VaoPackedArray::ID VaoID;
typedef VboPackedArray::ID VboID;
typedef RboPackedArray::ID RboID;
typedef FboPackedArray::ID FboID;
typedef ShaderPackedArray::ID ShaderID;
typedef MaterialPackedArray::ID MaterialID;

TRE_NS_END