#pragma once

#include <algorithm>
#include <atomic>
#include <mutex>
#include <condition_variable>

#include "Core/Misc/Maths/Maths.hpp"
#include "Core/Misc/Defines/Common.hpp"
#include "Core/DataStructure/Tuple/Pair.hpp"
#include "Core/Memory/Allocators/LinearAlloc/LinearAllocator.hpp"

#include "RenderEngine/Scenegraph/Scene/Scene.hpp"
#include "RenderEngine/Renderer/Frontend/Camera/Camera.hpp"
#include "RenderEngine/Renderer/Backend/CommandPacket/CommandPacket.hpp"
#include "RenderEngine/Managers/ResourcesManager/ResourcesManager.hpp"

TRE_NS_START

template<typename T>
class CommandBucket
{
public:
    typedef T Key;

    CommandBucket();
    
    template<typename U>
    U* AddCommand(Key key, usize aux_memory = 0);

    template <typename U, typename V>
    U* AppendCommand(V* command, usize aux_memory = 0);

    Key GenerateKey(typename RMI<ShaderProgram>::ID shaderID, typename RMI<VAO>::ID vaoID, typename RMI<Material>::ID matID) const;

    void DecodeKey(Key key, typename RMI<ShaderProgram>::ID& shaderID, typename RMI<VAO>::ID& vaoID, typename RMI<Material>::ID& matID) const;

    void Submit(const Scene& scene);

    void Sort();

    void Clear();

    bool SwapCmdBuffer();
private:
    void SubmitPacket(const CmdPacket packet) const;

public:
    Pair<Key, uint32>* m_Keys[2];
    void** m_Packets[2];
    LinearAlloc m_Allocators[2];
    uint32 m_Current[2];
    uint8 m_CurrentCmdBuffer;
    std::mutex mtx;
    std::condition_variable cv;
    bool m_IsReading;
    
    CONSTEXPR static uint8  READ_CMD_BUFFER  = 0;
    CONSTEXPR static uint8  WRITE_CMD_BUFFER = 1;
    CONSTEXPR static uint32 DEFAULT_CAPACITY = 1024;
    CONSTEXPR static uint32 DEFAULT_SIZE     = DEFAULT_CAPACITY * (sizeof(Pair<Key, uint32>) + sizeof(void*));
};

template<typename T>
using CommandBuffer = CommandBucket<T>;

#include "CommandBucket.inl"

TRE_NS_END