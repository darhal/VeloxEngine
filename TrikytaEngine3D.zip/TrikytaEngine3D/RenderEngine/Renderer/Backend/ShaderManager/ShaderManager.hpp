#pragma once

#include "Core/Misc/Defines/Common.hpp"

TRE_NS_START

class ShaderManager
{

};

TRE_NS_END