#pragma once

#include <Core/Misc/Defines/Common.hpp>
#include <RenderEngine/Renderer/Common/Common.hpp>
#include <RenderAPI/General/GLContext.hpp>

TRE_NS_START

struct StateGroup
{
    bool depth_enabled = true;
    TestFunction::test_function_t depth_func = TestFunction::LESS;

    bool cull_enabled = true;
    CullMode::front_face_t frontface = CullMode::front_face_t::CW;
    CullMode::cull_mode_t cullmode = CullMode::cull_mode_t::BACK;

    PolygonMode::polygon_mode_t poly_mode = PolygonMode::FILL;

    uint8 GetSortKey() const
    {
        return depth_enabled << 1 | cull_enabled;
    }
    
    // Output 7 bits code.
    StateHash GetHash() const 
    { 
        return 
        (GetSortKey() << (CullMode::GetEncodingBits() + TestFunction::GetEncodingBits() + PolygonMode::GetEncodingBits())) | 
        TestFunction::Encode(depth_func) << (CullMode::GetEncodingBits() + PolygonMode::GetEncodingBits()) | 
        CullMode::Encode(frontface, cullmode) << PolygonMode::GetEncodingBits() |
        PolygonMode::Encode(poly_mode); 
    };

    void ApplyStates() const
    {
        if (depth_enabled){
            Enable(Capability::DEPTH_TEST);
            glDepthFunc(depth_func);
        }else{
            Disable(Capability::DEPTH_TEST);
        }

        if (cull_enabled){
            Enable(Capability::CULL_FACE);
            Call_GL(glFrontFace(frontface));
	        Call_GL(glCullFace(cullmode));
        }else{
            Disable(Capability::CULL_FACE);
        }

        
        Call_GL(glPolygonMode(GL_FRONT_AND_BACK, poly_mode));
    }
};

FORCEINLINE bool operator==(const StateGroup& a, const StateGroup& b)
{
    return a.GetHash() == b.GetHash();
}

FORCEINLINE bool operator!=(const StateGroup& a, const StateGroup& b)
{
    return !(a == b);
}

TRE_NS_END