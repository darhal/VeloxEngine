#include "DrawCallsDispatcher.hpp"
#include "RenderAPI/General/GLContext.hpp"
#include "RenderEngine/Renderer/Commands/Commands.hpp"

TRE_NS_START

void BackendDispatch::Draw(const void* data)
{
    const Commands::Draw* real_data = reinterpret_cast<const Commands::Draw*>(data);
    DrawArrays(real_data->mode, real_data->start, real_data->end);
}

TRE_NS_END