#include "DrawCallsDispatcher.hpp"
#include "RenderAPI/VertexArray/VAO.hpp"
#include "RenderAPI/VertexBuffer/VBO.hpp"
#include "RenderAPI/General/GLContext.hpp"
#include "RenderEngine/Renderer/Commands/Commands.hpp"
#include "RenderEngine/Managers/ResourcesManager/ResourcesManager.hpp"
#include "RenderEngine/Mesh/ModelLoader/ModelLoader.hpp"

TRE_NS_START

void BackendDispatch::Draw(const void* data)
{
    const Commands::DrawCmd* real_data = reinterpret_cast<const Commands::DrawCmd*>(data);
    DrawArrays(real_data->mode, real_data->start, real_data->end);
}

void BackendDispatch::DrawIndexed(const void* data)
{
    const Commands::DrawIndexedCmd* real_data = reinterpret_cast<const Commands::DrawIndexedCmd*>(data);
    DrawElements(real_data->mode, real_data->type, real_data->count, real_data->offset);
}

void BackendDispatch::GenerateVAO(const void* data)
{
    const Commands::GenerateVAOCmd* real_data = reinterpret_cast<const Commands::GenerateVAOCmd*>(data);
    VAO* modelVAO = real_data->m_VAO;

    modelVAO->Generate();
	modelVAO->Use();

    usize index_attrib = 0;

    for(const IVariable& var : real_data->m_VariablesSet){
        typename RMI<VBO>::ID vboID;
	    VBO* vertexVBO = ResourcesManager::GetGRM().Create<VBO>(vboID);
	    vertexVBO->Generate(BufferTarget::ARRAY_BUFFER);
        const VariableDesc& desc = var.GetVariableDesc();
	    vertexVBO->FillData(var.GetDataPtr(), desc.count * desc.size);
	    modelVAO->BindAttribute<DataType::FLOAT>(index_attrib, *vertexVBO, desc.size, 0, 0);
        index_attrib++;
    }
}

void BackendDispatch::GenerateVAOFromVertexData(const void* data)
{
    const Commands::GenerateVAOFromVertexDataCmd* real_data = reinterpret_cast<const Commands::GenerateVAOFromVertexDataCmd*>(data);
    VAO* modelVAO = real_data->m_VAO;

    modelVAO->Generate();
	modelVAO->Use();

    const Variable<VertexData, VertexDataDesc>& var = real_data->variable;

    typename RMI<VBO>::ID vboID;
	VBO* vertexVBO = ResourcesManager::GetGRM().Create<VBO>(vboID);
	vertexVBO->Generate(BufferTarget::ARRAY_BUFFER);
    const VertexDataDesc& desc = var.GetConcreteDesc();
	vertexVBO->FillData(var.GetDataPtr(), desc.count * desc.size);
    printf("----------------------COMMAND DATA--------------------------\n");
    printf("- Vert data pointer = %p\n", var.GetDataPtr());
    printf("- Var Count = %d | Var Size = %lu\n", desc.count, desc.size);

    uint32 total = desc.indv_count[0] + desc.indv_count[1] + desc.indv_count[2]; 
    intptr offset = 0;

    for(uint8 i = 0; i < 3; i++){
        uint32 count = desc.indv_count[i];
        modelVAO->BindAttribute<float>(VertexDataDesc::VERTEX + i, *vertexVBO, DataType::FLOAT, count, total, offset);
        printf("- BindAttrib(%d, %d, %d)\n", count, total, (uint32)offset);
        offset += count;
    }  
    printf("-------------- END OF COMMAND DATA ------------------------\n");
}

void BackendDispatch::GenerateIndex(const void* data)
{
    const Commands::GenerateIndexCmd* real_data = reinterpret_cast<const Commands::GenerateIndexCmd*>(data);
    VAO* modelVAO = real_data->m_VAO;
    const IVariable& var = real_data->m_IndexVariable;
    const VariableDesc& desc = var.GetVariableDesc();

    typename RMI<VBO>::ID indexVboID;
	VBO* indexVBO = ResourcesManager::GetGRM().Create<VBO>(indexVboID);

	//Set up indices
	indexVBO->Generate(BufferTarget::ELEMENT_ARRAY_BUFFER);
	indexVBO->FillData(var.GetDataPtr(), desc.count * desc.size);
	modelVAO->Unbind();
	indexVBO->Unbind();

    printf("----------------------INDEX COMMAND DATA--------------------------\n");
    printf("- count = %d | size = %lu\n", desc.count, desc.size);
    printf("----------------- END OF COMMAND DATA ---------------------\n");
}

TRE_NS_END