#include "DrawCallsDispatcher.hpp"
#include "RenderAPI/General/GLContext.hpp"
#include "RenderEngine/Renderer/Commands/Commands.hpp"

TRE_NS_START

void BackendDispatch::Draw(const void* data)
{
    const Commands::Draw* real_data = reinterpret_cast<const Commands::Draw*>(data);
    DrawArrays(real_data->mode, real_data->start, real_data->end);
}

void BackendDispatch::DrawIndexed(const void* data)
{
    const Commands::DrawIndexed* real_data = reinterpret_cast<const Commands::DrawIndexed*>(data);
    DrawElements(real_data->mode, real_data->type, real_data->count, real_data->offset);
}

TRE_NS_END