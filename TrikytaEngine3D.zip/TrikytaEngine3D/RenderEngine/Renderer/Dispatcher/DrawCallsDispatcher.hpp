#pragma once

#include "Core/Misc/Defines/Common.hpp"

TRE_NS_START

struct BackendDispatch
{
    static void Draw(const void* data);
    static void DrawIndexed(const void* data);
};


TRE_NS_END