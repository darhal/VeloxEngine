#pragma once

#include <Core/Misc/Defines/Common.hpp>
#include <RenderEngine/Renderer/Common/Common.hpp>

TRE_NS_START

typedef class RenderResourcesManager RRM;

class RenderResourcesManager
{
public:
    RenderResourcesManager() {};

    // Add Functions

    FORCEINLINE TexturePackedArray::ID AddTexture(Texture&& tex);

    FORCEINLINE VaoPackedArray::ID AddVAO(VAO&& vao);

    FORCEINLINE VboPackedArray::ID AddVBO(VBO&& vbo);

    FORCEINLINE RboPackedArray::ID AddRBO(RBO&& rbo);

    FORCEINLINE FboPackedArray::ID AddFBO(FBO&& fbo);

    FORCEINLINE ShaderPackedArray::ID AddShader(ShaderProgram&& shader);

    FORCEINLINE MaterialPackedArray::ID AddMaterial(Material&& material);

    // Remove Functions

    FORCEINLINE void RemoveTexture(TexturePackedArray::ID id);

    FORCEINLINE void RemoveVAO(VaoPackedArray::ID id);

    FORCEINLINE void RemoveVBO(VboPackedArray::ID id);

    FORCEINLINE void RemoveRBO(RboPackedArray::ID id);

    FORCEINLINE void RemoveFBO(FboPackedArray::ID id);

    FORCEINLINE void RemoveShader(ShaderPackedArray::ID id);

    FORCEINLINE void RemoveMaterial(MaterialPackedArray::ID id);

    // Get Functions

    FORCEINLINE Texture& GetTexture(TexturePackedArray::ID id);

    FORCEINLINE VAO& GetVAO(VaoPackedArray::ID id);

    FORCEINLINE VBO& GetVBO(VboPackedArray::ID id);

    FORCEINLINE RBO& GetRBO(RboPackedArray::ID id);

    FORCEINLINE FBO& GetFBO(FboPackedArray::ID id);

    FORCEINLINE ShaderProgram& GetShader(ShaderPackedArray::ID id);

    FORCEINLINE Material& GetMaterial(MaterialPackedArray::ID id);

    //  Get Packed Arrays
    
    FORCEINLINE TexturePackedArray& GetTextureArray() { return m_Textures; }

    FORCEINLINE VaoPackedArray& GetVaoArray() { return m_VAOs; }

    FORCEINLINE VboPackedArray& GetVboArray() { return m_VBOs; }

    FORCEINLINE RboPackedArray& GetRboArray() { return m_RBOs; }

    FORCEINLINE FboPackedArray& GetFboArray() { return m_FBOs; }

    FORCEINLINE ShaderPackedArray& GetShaderArray() { return m_Shaders; }

    FORCEINLINE MaterialPackedArray& GetMaterialArray() { return m_Materials; }

private:
    TexturePackedArray m_Textures;
    VaoPackedArray m_VAOs;
    VboPackedArray m_VBOs;
    RboPackedArray m_RBOs;
    FboPackedArray m_FBOs;
    ShaderPackedArray m_Shaders;
    MaterialPackedArray m_Materials;
};

#include "RenderResourcesManager.inl"

TRE_NS_END