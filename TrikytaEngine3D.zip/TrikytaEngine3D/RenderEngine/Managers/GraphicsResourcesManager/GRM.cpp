#include "GRM.hpp"

TRE_NS_START

RMI<Texture>::Container GraphicsResourcesManager::m_Textures;
RMI<VAO>::Container GraphicsResourcesManager::m_VAOs;
RMI<VBO>::Container GraphicsResourcesManager::m_VBOs;
RMI<RBO>::Container GraphicsResourcesManager::m_RBOs;
RMI<FBO>::Container GraphicsResourcesManager::m_FBOs;
RMI<ShaderProgram>::Container GraphicsResourcesManager::m_Shaders;
RMI<Material>::Container GraphicsResourcesManager::m_Materials;

TRE_NS_END