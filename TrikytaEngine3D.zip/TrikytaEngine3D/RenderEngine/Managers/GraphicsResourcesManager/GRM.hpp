#pragma once

#include <Core/Misc/Defines/Common.hpp>
#include <Core/DataStructure/PackedArray/PackedArray.hpp>
#include <RenderEngine/Renderer/Common/Common.hpp>

TRE_NS_START

class GraphicsResourcesManager
{
public:
    template<typename T, typename... Args>
    FORCEINLINE typename RMI<T>::ID Generate(Args&&... args);

    template<typename T, typename... Args>
    FORCEINLINE T* Create(typename RMI<T>::ID& id, Args&&... args);

    // Add Function
    template<typename T>
    FORCEINLINE typename RMI<T>::ID Add(T&& res);

    // Get Function
    template<typename T>
    FORCEINLINE T& Get(typename RMI<T>::ID id);

    // Remove Function
    template<typename T>
    FORCEINLINE void Remove(typename RMI<T>::ID id);

    //  Get Packed Array
    template<typename T>
    FORCEINLINE typename RMI<T>::Container& GetResourceContainer();

private:
    RMI<Texture>::Container m_Textures;
    RMI<VAO>::Container m_VAOs;
    RMI<VBO>::Container m_VBOs;
    RMI<RBO>::Container m_RBOs;
    RMI<FBO>::Container m_FBOs;
    RMI<ShaderProgram>::Container m_Shaders;
    RMI<Material>::Container m_Materials;

};

using GRM = GraphicsResourcesManager;

#include "GRM.inl"

TRE_NS_END