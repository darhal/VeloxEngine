#pragma once

#include <Core/Misc/Defines/Common.hpp>
#include <Core/DataStructure/PackedArray/PackedArray.hpp>
#include <RenderEngine/Renderer/Common/Common.hpp>

TRE_NS_START

class GraphicsResourcesManager
{
public:
    template<typename T, typename... Args>
    FORCEINLINE static typename RMI<T>::ID Generate(Args&&... args);

    template<typename T, typename... Args>
    FORCEINLINE static T* Create(typename RMI<T>::ID& id, Args&&... args);

    // Add Function
    template<typename T>
    FORCEINLINE static typename RMI<T>::ID Add(T&& res);

    // Get Function
    template<typename T>
    FORCEINLINE static T& Get(typename RMI<T>::ID id);

    // Remove Function
    template<typename T>
    FORCEINLINE static void Remove(typename RMI<T>::ID id);

    //  Get Packed Array
    template<typename T>
    FORCEINLINE static typename RMI<T>::Container GetResourceContainer();

    static RMI<Texture>::Container m_Textures;
    static RMI<VAO>::Container m_VAOs;
    static RMI<VBO>::Container m_VBOs;
    static RMI<RBO>::Container m_RBOs;
    static RMI<FBO>::Container m_FBOs;
    static RMI<ShaderProgram>::Container m_Shaders;
    static RMI<Material>::Container m_Materials;
};

using GRM = GraphicsResourcesManager;

#include "GRM.inl"

TRE_NS_END