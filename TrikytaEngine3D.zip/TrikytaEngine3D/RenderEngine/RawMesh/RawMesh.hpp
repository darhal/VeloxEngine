#pragma once

#include "Core/Misc/Defines/Common.hpp"
#include "RenderAPI/VertexArray/VAO.hpp"
#include "RenderAPI/General/GLContext.hpp"

TRE_NS_START

struct RawMesh
{
public:
    RawMesh(VAO& vao, int32 count, intptr offset = 0, 
        Primitive::primitive_t primitive = Primitive::TRIANGLES, DataType::data_type_t data_type = DataType::UINT) : 
        m_VAO(vao), m_Primitive(primitive), m_Count(count), m_Offset(offset), m_DataType(data_type)
    {}

    RawMesh(VAO& vao, int32 start, int32 end, 
        Primitive::primitive_t primitive = Primitive::TRIANGLES) : 
        m_VAO(vao), m_Primitive(primitive), m_Start(start), m_End(end)
    {}

    const VAO& GetVAO() const { return m_VAO; }

    const Primitive::primitive_t& GetPrimitive() const { return m_Primitive; }

    VAO& m_VAO;
    Primitive::primitive_t m_Primitive;

    union {
        struct {
            int32 m_Count; 
            intptr m_Offset;
            DataType::data_type_t m_DataType; 
        };

        struct {
            int32 m_Start;
            int32 m_End;
        };
    };
};

TRE_NS_END