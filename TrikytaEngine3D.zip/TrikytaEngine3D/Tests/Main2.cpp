//#ifdef BLABLA
#include <RenderAPI/Shader/ShaderProgram.hpp>
#include <RenderAPI/Shader/Shader.hpp>
#include <RenderAPI/VertexArray/VAO.hpp>
#include <RenderAPI/VertexBuffer/VBO.hpp>
#include <RenderAPI/Texture/Texture.hpp>
#include <RenderAPI/General/GLContext.hpp>
#include <RenderAPI/RenderBuffer/RBO.hpp>
#include <RenderAPI/FrameBuffer/FBO.hpp>

#include <Core/Context/Extensions.hpp>
#include <Core/Window/Window.hpp>
#include <iostream>
#include <chrono>
#include <Core/Misc/Maths/Maths.hpp>
#include <Core/Misc/Utils/Image.hpp>
#include <thread>
#include <future>
#include <Core/Context/Context.hpp>


#include <RenderEngine/Loader/MeshLoader.hpp>
#include <RenderEngine/Mesh/ModelLoader/ModelLoader.hpp>
#include <RenderAPI/GlobalState/GLState.hpp>

#include <RenderEngine/Renderer/Camera/Camera.hpp>
#include <Core/FileSystem/Directory/Directory.hpp>
#include <Core/Memory/Allocators/StackAlloc/DoubleStackAllocator.hpp>
#include <RenderEngine/Mesh/StaticMesh/StaticMesh.hpp>
#include <time.h>
#include <Core/TaskSystem/TaskManager/TaskManager.hpp>
#include <Core/DataStructure/PackedArray/PackedArray.hpp>
#include <RenderEngine/Managers/ResourcesManager/ResourcesManager.hpp>
#include <RenderEngine/Scenegraph/Scene/Scene.hpp>
#include <RenderEngine/Renderer/CommandBucket/CommandBucket.hpp>

using namespace TRE;

// set up vertex data (and buffer(s)) and configure vertex attributes
// ------------------------------------------------------------------
float vertices[] = {
	-0.5f, -0.5f, -0.5f, 
	0.5f, -0.5f, -0.5f, 
	0.5f,  0.5f, -0.5f,  
	0.5f,  0.5f, -0.5f, 
	-0.5f,  0.5f, -0.5f,  
	-0.5f, -0.5f, -0.5f, 

	-0.5f, -0.5f,  0.5f,  
	0.5f, -0.5f,  0.5f,  
	0.5f,  0.5f,  0.5f,  
	0.5f,  0.5f,  0.5f,  
	-0.5f,  0.5f,  0.5f,  
	-0.5f, -0.5f,  0.5f, 

	-0.5f,  0.5f,  0.5f,  
	-0.5f,  0.5f, -0.5f, 
	-0.5f, -0.5f, -0.5f,  
	-0.5f, -0.5f, -0.5f,  
	-0.5f, -0.5f,  0.5f, 
	-0.5f,  0.5f,  0.5f,  

	0.5f,  0.5f,  0.5f,  
	0.5f,  0.5f, -0.5f,  
	0.5f, -0.5f, -0.5f,  
	0.5f, -0.5f, -0.5f,  
	0.5f, -0.5f,  0.5f, 
	0.5f,  0.5f,  0.5f, 

	-0.5f, -0.5f, -0.5f,  
	0.5f, -0.5f, -0.5f,  
	0.5f, -0.5f,  0.5f,  
	0.5f, -0.5f,  0.5f,  
	-0.5f, -0.5f,  0.5f,  
	-0.5f, -0.5f, -0.5f,  

	-0.5f,  0.5f, -0.5f,  
	0.5f,  0.5f, -0.5f,  
	0.5f,  0.5f,  0.5f,  
	0.5f,  0.5f,  0.5f,  
	-0.5f,  0.5f,  0.5f, 
	-0.5f,  0.5f, -0.5f,  
};

float texCoord[] = {
	0.0f, 0.0f,
	1.0f, 0.0f,
	1.0f, 1.0f,
	1.0f, 1.0f,
	0.0f, 1.0f,
	0.0f, 0.0f,

	0.0f, 0.0f,
	1.0f, 0.0f,
	1.0f, 1.0f,
	1.0f, 1.0f,
	0.0f, 1.0f,
	0.0f, 0.0f,

	1.0f, 0.0f,
	1.0f, 1.0f,
	0.0f, 1.0f,
	0.0f, 1.0f,
	0.0f, 0.0f,
	1.0f, 0.0f,

	1.0f, 0.0f,
	1.0f, 1.0f,
	0.0f, 1.0f,
	0.0f, 1.0f,
	0.0f, 0.0f,
	1.0f, 0.0f,

	0.0f, 1.0f,
	1.0f, 1.0f,
	1.0f, 0.0f,
	1.0f, 0.0f,
	0.0f, 0.0f,
	0.0f, 1.0f,

	0.0f, 1.0f,
	1.0f, 1.0f,
	1.0f, 0.0f,
	.0f, 0.0f,
	0.0f, 0.0f,
	0.0f, 1.0f
};

// world space positions of our cubes
vec3 cubePositions[] = {
	vec3(0.0f,  0.0f,  0.0f),
	vec3(2.0f,  5.0f, -15.0f),
	vec3(-1.5f, -2.2f, -2.5f),
	vec3(-3.8f, -2.0f, -12.3f),
	vec3(2.4f, -0.4f, -3.5f),
	vec3(-1.7f,  3.0f, -7.5f),
	vec3(1.3f, -2.0f, -2.5f),
	vec3(1.5f,  2.0f, -2.5f),
	vec3(1.5f,  0.2f, -1.5f),
	vec3(-1.3f,  1.0f, -1.5f)
};

// settings
const unsigned int SCR_WIDTH = 1920 / 2;
const unsigned int SCR_HEIGHT = 1080 / 2;

float lastX = (float)SCR_WIDTH / 2.0;
float lastY = (float)SCR_HEIGHT / 2.0;
bool firstMouse = true;

// camera
Camera camera(vec3(0.0f, 0.0f, 3.0f));
clock_t deltaTime = 0;
unsigned int frames = 0;
double  frameRate = 30;
double  averageFrameTimeMilliseconds = 33.333;
bool vsync = true;
bool start = false;
int32 speed = 1.0;

double clockToMilliseconds(clock_t ticks){
    // units/(units/time) => time (seconds) * 1000 = milliseconds
    return (ticks/(double)CLOCKS_PER_SEC)*1000.0;
}

void HandleEvent(Scene& scene, const Event&);
void clip(const TRE::Window&);

void RenderThread()
{
	TRE::Window window(SCR_WIDTH, SCR_HEIGHT, "Trikyta ENGINE 3 (OpenGL 3.3)", WindowStyle::Resize);
	window.initContext(3, 3);
	
	printf("- GPU Vendor    	: %s\n", glGetString(GL_VENDOR));
	printf("- Graphics      	: %s\n", glGetString(GL_RENDERER));
	printf("- Version       	: %s\n", glGetString(GL_VERSION));
	printf("- GLSL Version  	: %s\n", glGetString(GL_SHADING_LANGUAGE_VERSION));
	printf("- Hardware Threads 	: %d\n", std::thread::hardware_concurrency()); 

	typename RMI<ShaderProgram>::ID shaderID, texShaderID;
	
	ShaderProgram* ourShader = ResourcesManager::GetGRM().Create<ShaderProgram>(shaderID, 
		Shader("res/Shader/cam.vs", ShaderType::VERTEX).GetID(),
		Shader("res/Shader/cam.fs", ShaderType::FRAGMENT).GetID()
	);

	ShaderProgram* texOurShader = ResourcesManager::GetGRM().Create<ShaderProgram>(texShaderID, 
		Shader("res/Shader/texture.vs", ShaderType::VERTEX).GetID(),
		Shader("res/Shader/texture.fs", ShaderType::FRAGMENT).GetID()
	);

	Scene scene;
	Directory res_dir("res/");
	String mesh_file_path;
	StaticMesh trees;
	{
		mesh_file_path.Clear();
		res_dir.SearchRecursive("all_combined_hard.obj", mesh_file_path);
		MeshLoader obj_loader(mesh_file_path.Buffer());
		ModelLoader loader(std::move(obj_loader.LoadAsOneObject(scene)));
		loader.ProcessData(trees);
		scene.AddMeshInstance(&trees);
	}
	scene.GetRenderCommandBuffer().Clear();
	scene.Submit();
	scene.Render();

	/*Vector<StaticMesh> models;
	{
		res_dir.SearchRecursive("all_combined_hard.obj", mesh_file_path);
		MeshLoader obj_loader(mesh_file_path.Buffer());
		Vector<ModelLoader> loaders;
		obj_loader.ProcessData(loaders);

		for (ModelLoader& loader : loaders){
			StaticMesh mesh;
			loader.ProcessData(mesh);
			StaticMesh& m = models.EmplaceBack(std::move(mesh));
			m.Submit(cmdBucket, shaderID);
		}
	}*/


	ourShader->Use();
	ourShader->SetVec3("light.ambient", 0.09f, 0.09f, 0.09f);
	ourShader->SetVec3("light.diffuse", 1.0f, 1.0f, 1.0f);
	ourShader->SetVec3("light.specular", 0.1f, 0.1f, 0.1f);
	ourShader->SetVec3("light.position", 0.f, 15.f, 0.f);

	texOurShader->Use();
	texOurShader->SetVec3("light.ambient", 0.09f, 0.09f, 0.09f);
	texOurShader->SetVec3("light.diffuse", 1.0f, 1.0f, 1.0f);
	texOurShader->SetVec3("light.specular", 0.1f, 0.1f, 0.1f);
	texOurShader->SetVec3("light.position", 0.f, 15.f, 0.f);
	texOurShader->SetInt("material.diffuse_tex", 0);
	texOurShader->SetInt("material.specular_tex", 1);

	Enable(Capability::DEPTH_TEST);
	Enable(GL_MULTISAMPLE);
	//glEnable(GL_CULL_FACE);
	//glCullFace(GL_FRONT);
	//glFrontFace(GL_CW);

	
	Event ev;
	// clock_t fps;

	while (window.isOpen())
	{
		clock_t beginFrame = clock();
		if (window.getEvent(ev)) {
			HandleEvent(scene, ev);
		}

		ClearColor({ 51.f, 76.5f, 76.5f, 255.f });
		Clear();
		
		scene.Render();
	
		window.Present();

		clock_t endFrame = clock();
		deltaTime += endFrame - beginFrame;
		frames++;

		if (start)
			trees.GetTransformationMatrix().rotate(vec3(0.f, 0.f, 1.f), speed*(clockToMilliseconds(endFrame - beginFrame)/1000.0));
		
		//if(endFrame - beginFrame > 0)
       	// 	fps = CLOCKS_PER_SEC / (endFrame - beginFrame);
    	//printf("Delta Time : %lf ms - FPS : %lu\n", clockToMilliseconds(endFrame - beginFrame), fps);
	}

}

void empty_job1(Job* t, const void*)
{
	printf("Hello! From %d\n", t->m_WorkerID);
}

void empty_job2(Job* t, const void*)
{
	printf("Hello! From %d\n", t->m_WorkerID);
}


void DoJobs1(TaskExecutor* ts, int8 x)
{
	Task* root = Task::CreateTask(&empty_job1);
	ts->Run(root);
	for (usize i = 0; i < 7; i++){
		Task* t = Task::CreateTask(&empty_job1);
		ts->Run(t);
	}
	ts->Wait(root);
}

void DoJobs2(TaskExecutor* ts, int8 x)
{
	Task* root = Task::CreateTask(&empty_job1);
	ts->Run(root);
	for (usize i = 0; i < 3; i++){
		Task* t = Task::CreateTask(&empty_job2);
		ts->Run(t);
	}
	ts->Wait(root);
}

int main()
{	
	RenderThread();
}


void PrintScreenshot()
{
	Color* pixels = new Color[SCR_WIDTH*SCR_HEIGHT];
	glReadPixels(0, 0, SCR_WIDTH, SCR_HEIGHT, GL_RGBA, GL_UNSIGNED_BYTE, pixels);
	Image img = Image(SCR_WIDTH, SCR_HEIGHT, pixels);
	img.Save("test.png", ImageFileFormat::PNG);
	printf("Screenshot taken.\n");
	delete[] pixels;
}

void HandleEvent(Scene& scene, const Event& e)
{
	if (e.Type == Event::TE_RESIZE) {
		glViewport(0, 0, e.Window.Width, e.Window.Height);
		scene.CreateProjectionMatrix(Vec2f(e.Window.Width, e.Window.Height), Scene::NEAR_PLANE, Scene::FAR_PLANE);
		printf("DETECTING RESIZE EVENT(%d, %d)\n", e.Window.Width, e.Window.Height);
	}else if (e.Type == Event::TE_KEY_DOWN) {
		if (e.Key.Code == Key::F11) {
			PrintScreenshot();
			printf("Taking screenshot...\n");
		}
		switch (e.Key.Code) {
		case Key::Up:
			speed += 1;
			break;
		case Key::Down:
			speed -= 1;
			break;
		case Key::Space:
			start = !start;
			deltaTime = 0;
			break;
		case Key::Z:
			scene.GetCurrentCamera()->ProcessKeyboard(FORWARD, (float)clockToMilliseconds(deltaTime)/1000.0);
			break;
		case Key::S:
			scene.GetCurrentCamera()->ProcessKeyboard(BACKWARD, (float)clockToMilliseconds(deltaTime)/1000.0);
			break;
		case Key::Q:
			scene.GetCurrentCamera()->ProcessKeyboard(LEFT, (float)clockToMilliseconds(deltaTime)/1000.0);
			break;
		case Key::D:
			scene.GetCurrentCamera()->ProcessKeyboard(RIGHT, (float)clockToMilliseconds(deltaTime)/1000.0);
			break;
		default:
			break;
		}
	}else if (e.Type == Event::TE_MOUSE_MOVE) {
		float xpos = (float)e.Mouse.X;
		float ypos = (float)e.Mouse.Y;
		if (firstMouse) {
			lastX = xpos;
			lastY = ypos;
			firstMouse = false;
		}

		float xoffset = xpos - lastX;
		float yoffset = lastY - ypos; // reversed since y-coordinates go from bottom to top

		lastX = xpos;
		lastY = ypos;

		scene.GetCurrentCamera()->ProcessMouseMovement(xoffset, yoffset);
	}
}

/*void clip(const Window& win)
{
	RECT _clip;
	HWND _window = win.window;

	//Create a RECT out of the window
	GetWindowRect(_window, &_clip);

	//Modify the rect slightly, so the frame doesn't get clipped with
	_clip.left += 5;
	_clip.top += 30;
	_clip.right -= 5;
	_clip.bottom -= 5;

	//Clip the RECT
	ClipCursor(&_clip);
	ShowCursor(FALSE);

}*/

//#endif