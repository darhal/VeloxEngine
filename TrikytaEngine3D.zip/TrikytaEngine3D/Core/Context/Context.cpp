#include "Context.hpp"
#include "Extensions.hpp"

TRE::Context TRE::Context::UseExistingContext()
{
	return Context();
}
