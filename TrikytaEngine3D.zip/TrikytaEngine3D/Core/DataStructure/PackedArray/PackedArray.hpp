#pragma once

#include <limits>
#include "Core/Misc/Defines/Common.hpp"
#include "Core/DataStructure/Tuple/Pair.hpp"

TRE_NS_START

template<typename T, usize MAX_OBJECTS = 64 * 1024, typename ID_TYPE = uint32, typename INDEX_TYPE = uint16>
class PackedArray
{
public:
	typedef ID_TYPE ID_t;
	typedef INDEX_TYPE INDEX_t;

    typedef ID_TYPE ID;
    typedef Pair<ID, T> Object; // First the ID then the Object.

    CONSTEXPR static INDEX_TYPE MAX = std::numeric_limits<INDEX_TYPE>::max();
    CONSTEXPR static INDEX_TYPE INDEX_MASK = std::numeric_limits<INDEX_TYPE>::max();
    CONSTEXPR static ID_TYPE NEW_OBJECT_ID_ADD = std::numeric_limits<INDEX_TYPE>::max() + 1;

    struct Index {
	    ID id;
	    INDEX_TYPE index;
	    INDEX_TYPE next;
    };

    PackedArray();

	FORCEINLINE INDEX_TYPE CompressID(ID id) const;

	FORCEINLINE bool Has(ID id);
	
	FORCEINLINE Object& Lookup(ID id);
	
	ID Add(const T& obj);

	ID Add(T&& obj);

	template<typename... Args>
	ID Emplace(Args&&... args);
	
	void Remove(ID id);

private:
    Object* m_Objects; // Object m_Objects[MAX_OBJECTS];
 	Index m_Indices[MAX_OBJECTS];

    ID m_NumObjects;
    INDEX_TYPE m_FreelistEnqueue;
	INDEX_TYPE m_FreelistDequeue;
};

#include "PackedArray.inl"

TRE_NS_END
