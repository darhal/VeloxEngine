#pragma once

#include <limits.h>
#include "Core/Misc/Defines/Common.hpp"
#include "Core/DataStructure/Tuple/Pair.hpp"

TRE_NS_START

template<typename T, usize MAX_OBJECTS = 64 * 1024, typename ID_TYPE = uint32, typename INDEX_TYPE = uint16>
class PackedArray
{
public:
    typedef ID_TYPE ID;
    typedef Pair<ID, T> Object; // First the ID then the Object.

    CONSTEXPR static INDEX_TYPE MAX = std::numeric_limits<INDEX_TYPE>::max();
    CONSTEXPR static INDEX_TYPE INDEX_MASK = std::numeric_limits<INDEX_TYPE>::max();
    CONSTEXPR static ID_TYPE NEW_OBJECT_ID_ADD = std::numeric_limits<INDEX_TYPE>::max() + 1;

    struct Index {
	    ID id;
	    INDEX_TYPE index;
	    INDEX_TYPE next;
    };

    PackedArray() 
    {
		m_NumObjects = 0;

		for (ID i = 0; i < MAX_OBJECTS; ++i) {
			m_Indices[i].id = i;
			m_Indices[i].next = i+1;
		}

		m_FreelistDequeue = 0;
		m_FreelistEnqueue = MAX_OBJECTS - 1;
	}

	inline bool Has(ID id) 
    {
		Index& in = m_Indices[id & INDEX_MASK];
		return in.id == id && in.index != MAX;
	}
	
	inline Object& Lookup(ID id) 
    {
		return m_Objects[m_Indices[id & INDEX_MASK].index];
	}
	
	inline ID Add(T& obj) 
    {
		Index& in = m_Indices[m_FreelistDequeue];
		m_FreelistDequeue = in.next;
		in.id += NEW_OBJECT_ID_ADD;
		in.index = m_NumObjects++;
		Object& o = m_Objects[in.index];
        o.second = obj;  // Setup the object
		o.first = in.id; // o.first instead of o.id
		return o.first;
	}
	
	inline void Remove(ID id) 
    {
		Index& in = m_Indices[id & INDEX_MASK];
		
		Object& o = m_Objects[in.index];
		o = m_Objects[--m_NumObjects];
		m_Indices[o.first & INDEX_MASK].index = in.index; // o.first instead of o.id
		
		in.index = MAX;
		m_Indices[m_FreelistEnqueue].next = id & INDEX_MASK;
		m_FreelistEnqueue = id & INDEX_MASK;
	}

private:
    Object m_Objects[MAX_OBJECTS];
	Index m_Indices[MAX_OBJECTS];

    ID m_NumObjects;
    INDEX_TYPE m_FreelistEnqueue;
	INDEX_TYPE m_FreelistDequeue;
};

TRE_NS_END
