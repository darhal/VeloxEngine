#include "Core/Misc/Defines/Common.hpp"
#include "Core/Misc/Defines/Debug.hpp"

#include <atomic>

#if defined(COMPILER_MSVC)
#   include <windows.h>
#   define TASK_YIELD() YieldProcessor()
#   define TASK_COMPILER_BARRIER _ReadWriteBarrier()
#   define TASK_MEMORY_BARRIER std::atomic_thread_fence(std::memory_order_seq_cst);
#else
#   include <emmintrin.h>
#   define TASK_YIELD() _mm_pause()
#   define TASK_COMPILER_BARRIER asm volatile("" ::: "memory")
#   define TASK_MEMORY_BARRIER asm volatile("mfence" ::: "memory")
#endif

TRE_NS_START

class Task;

class WorkStealingQueue {
public:
    static usize BufferSize(int32 capacity) {
        return capacity * sizeof(Task*);
    }

    int32 Init(int32 capacity, void* buffer, usize bufferSize);
    int32 Push(Task* job);
    Task* Pop();
    Task* Steal();

private:
    Task** m_Entries;
    std::atomic<uint64_t> m_Top;
    uint64_t m_Bottom;
    int32 m_Capacity;
};

TRE_NS_END