#pragma once

#include "Core/Misc/Defines/Common.hpp"
#include "Core/TaskSystem/TaskScheduler/TaskScheduler.hpp"
#include "Core/Memory/Allocators/StackAlloc/DoubleStackAllocator.hpp"
#include <thread>

TRE_NS_START

class TaskManager
{
public:
    TaskManager(uint8 worker_count = std::thread::hardware_concurrency() - 1) : 
        m_Workers(NULL), m_WorkersCount(worker_count), m_TasksToDeleteCount(0)
    {
        m_Allocator.SetSize((m_WorkersCount + 10) * sizeof(Worker));
        m_Allocator.Init();
    };

    void BootUp();

    FORCEINLINE WorkStealingQueue* GetWorkingQueueByID(uint8 id) const;

    FORCEINLINE uint8 GetWorkerThreadCount() const;

    FORCEINLINE void QueueTaskForDeletion(const usize index, Task* t);

    FORCEINLINE void Run(Task* t);

private:
    CONSTEXPR static usize MAX_TASK_CAPACITY_PER_QUEUE = 1024u;
    CONSTEXPR static usize SIZE_OF_TASKS_PTR_PER_QUEUE = MAX_TASK_CAPACITY_PER_QUEUE * sizeof(Task*);

    struct Worker {
        TaskScheduler m_Scheduler;
        WorkStealingQueue m_WorkStealingQueue;
        std::thread m_WorkerThread;
    };

    Worker* m_Workers;
    StackAllocator m_Allocator;
    uint8 m_WorkersCount;
    Task* m_TasksToDelete[SIZE_OF_TASKS_PTR_PER_QUEUE];

public:
    std::atomic<usize> m_TasksToDeleteCount;
};

FORCEINLINE void TaskManager::BootUp() // shouldn't be inlined !
{
    // Worker* worker_ptr = (Worker*) m_Allocator.Allocate(sizeof(Worker) * m_WorkersCount, alignof(Worker));
    Worker* worker_ptr = (Worker*) operator new (sizeof(Worker) * m_WorkersCount ); 
    m_Workers = worker_ptr;
    for(uint8 id = 0; id < m_WorkersCount; id++){
        printf("Creating thread id = %d\n", id);
        new (&(worker_ptr[id].m_Scheduler)) TaskScheduler(this, id);
        new (&(worker_ptr[id].m_WorkStealingQueue)) WorkStealingQueue();
        void* buffer = operator new(SIZE_OF_TASKS_PTR_PER_QUEUE);
        reinterpret_cast<WorkStealingQueue*>(&(worker_ptr[id].m_WorkStealingQueue))->Init(MAX_TASK_CAPACITY_PER_QUEUE, buffer, SIZE_OF_TASKS_PTR_PER_QUEUE);
    }

    for(uint8 id = 0; id < m_WorkersCount; id++){
        new (&(worker_ptr[id].m_WorkerThread)) std::thread(&TaskScheduler::DoWork, &(worker_ptr[id].m_Scheduler));
        reinterpret_cast<std::thread*>(&(worker_ptr[id].m_WorkerThread))->detach();
    }    
}

FORCEINLINE WorkStealingQueue* TaskManager::GetWorkingQueueByID(uint8 id) const
{
    return &(m_Workers[id % m_WorkersCount].m_WorkStealingQueue);
}

FORCEINLINE uint8 TaskManager::GetWorkerThreadCount() const
{
    return m_WorkersCount;
}

FORCEINLINE void TaskManager::QueueTaskForDeletion(const usize index, Task* t)
{
    m_TasksToDelete[index - 1] = t;
}

FORCEINLINE void TaskManager::Run(Task* t)
{
    uint8 worker_id = GenerateRandomNumber(0, m_WorkersCount - 1);
    t->m_WorkerID = worker_id;
    m_Workers[worker_id].m_Scheduler.Run(t);    
}

TRE_NS_END