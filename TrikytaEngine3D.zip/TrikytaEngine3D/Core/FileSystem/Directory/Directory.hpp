#pragma once

#include "Core/Misc/Defines/Common.hpp"
#include "Core/DataStructure/String/String.hpp"
#include "Core/DataStructure/Vector/Vector.hpp"
#include "Core/DataStructure/Tuple/Pair.hpp"

#if defined(OS_LINUX) || defined(OS_UNIX)
    #include <sys/types.h>
    #include <sys/stat.h>
    #include <dirent.h>
    #include <unistd.h>
#elif defined(OS_WINDOWS)
    // TODO;
#endif

TRE_NS_START

class Directory
{
public:
    Directory(const String& path);

    bool IsRepository() const;

    bool IsFile() const;

    uint32 GetStatusChangeTime() const;

    uint32 GetLastFileAcessTime() const;

    uint32 GetFileModificationTime() const;

    uint32 GetOwnerUID() const;

    uint32 GetOwnerGID() const;

    int64 GetSize() const;

    void GetContent(Vector<String>& sub_dirs) const;

    void GetContentEx(Vector<Directory>& sub_dirs) const;

    Directory GetParent() const;

    const String& GetPath() const;
private:

    String m_DirPath;

#if defined(OS_LINUX) || defined(OS_UNIX)
    struct stat m_Informations;
#elif defined(OS_WINDOWS)
    // TODO;
#endif
};

TRE_NS_END