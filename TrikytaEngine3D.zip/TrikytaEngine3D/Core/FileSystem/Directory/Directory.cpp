#include "Directory.hpp"
#include "Core/Misc/Defines/Debug.hpp"

/*********************************************/
/******** LINUX/POS X Implementation *********/
/*********************************************/

#if defined(OS_LINUX) || defined(OS_UNIX)

TRE_NS_START

Directory::Directory(const String& path) : m_DirPath(path)
{
    int32 r = stat(m_DirPath.Buffer(), &m_Informations);
    ASSERTF(r == -1, "Failed to load direcoty informations (Linux implementation)");   
}

bool Directory::IsRepository() const
{
    return S_ISDIR(m_Informations.st_mode);
}

bool Directory::IsFile() const
{
    return S_ISREG(m_Informations.st_mode);
}

uint32 Directory::GetStatusChangeTime() const
{
    return m_Informations.st_ctim.tv_sec;
}


uint32 Directory::GetLastFileAcessTime() const
{
    return m_Informations.st_atim.tv_sec;
}

uint32 Directory::GetFileModificationTime() const
{
    return m_Informations.st_mtim.tv_sec;
}

uint32 Directory::GetOwnerUID() const
{
    return m_Informations.st_uid;
}

uint32 Directory::GetOwnerGID() const
{
    return m_Informations.st_gid;
}

int64 Directory::GetSize() const
{
    return m_Informations.st_size;
}

void Directory::GetContent(Vector<String>& sub_dirs) const
{
    DIR* dir = opendir(m_DirPath.Buffer());
    struct dirent* dir_info = readdir(dir);
    while (dir_info != NULL){
        if (dir_info->d_name[0] != '.') {
            String sub_path(dir_info->d_name, 0); // replace 0 with strlen(dir_info->d_name) + 3 to reproduce the bug!
            sub_path += String(dir_info->d_type == DT_DIR ? "/" : "", 0); // TODO : FIX POTENTIAL BUG IN STRING APPENDING WHEN WE PROVIDE THE LEN IN THE LINE JUST BEFORE!
            sub_dirs.EmplaceBack(sub_path);
        } 
        dir_info = readdir(dir);
    }
}

void Directory::GetContentEx(Vector<Directory>& sub_dirs) const
{
    DIR* dir = opendir(m_DirPath.Buffer());
    struct dirent* dir_info = readdir(dir);
    while (dir_info != NULL){
        if (dir_info->d_name[0] != '.') {
            String sub_path(m_DirPath);
            sub_path += dir_info->d_name;
            sub_path += String(dir_info->d_type == DT_DIR ? "/" : "", 0);
            sub_dirs.EmplaceBack(sub_path);
        } 
        dir_info = readdir(dir);
    }
}

Directory Directory::GetParent() const
{
    String parent_path = m_DirPath + "/..";
    DIR* d = opendir(parent_path.Buffer());
    struct dirent* dir_info = readdir(d);
    String parent_name(dir_info->d_name);
    return Directory(parent_name);
}

const String& Directory::GetPath() const
{
    return m_DirPath;
}

TRE_NS_END

#endif