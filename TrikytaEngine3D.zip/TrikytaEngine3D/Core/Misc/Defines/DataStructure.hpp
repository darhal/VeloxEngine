#pragma once

/*#include <vector>
#include <string>

template<typename T>
using Vector = std::vector<T>;
typedef std::string String;*/

#include <Core/DataStructure/Vector/Vector.hpp>
#include <Core/DataStructure/String/String.hpp>
#include <Core/DataStructure/HashMap/Map.hpp>
//#include <Core/DataStructure/HashMap/HashMap.hpp>